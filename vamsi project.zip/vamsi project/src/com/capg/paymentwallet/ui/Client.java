package com.capg.paymentwallet.ui;

import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

import com.capg.paymentwallet.bean.AccountBean;
import com.capg.paymentwallet.bean.CustomerBean;
import com.capg.paymentwallet.bean.WalletTransaction;
import com.capg.paymentwallet.service.AccountServiceImpl;
import com.capg.paymentwallet.service.IAccountService;

public class Client {
	   
	IAccountService service=new AccountServiceImpl();
	CustomerBean customer=new CustomerBean();
	Scanner scanner=new Scanner(System.in);
	
	
	
	public static void main(String[] args) throws Exception {
		IAccountService service=new AccountServiceImpl();
		char ch;
		Client client=new  Client();
		while(true)
		{
		System.out.println("****WELCOME****");
		System.out.println("1. Create Account ");
		System.out.println("2.  Deposite  ");
		System.out.println("3. Withdraw ");
		System.out.println("4. Show Balance ");
		System.out.println("5. Fund Transfer");
		System.out.println("6. Print Transactions");
		System.out.println("7. Exit");
		System.out.println("Choose an option");
		int option =client. scanner.nextInt();
		
		switch (option) {
		case 1:
			Scanner scanner=new Scanner(System.in);
			System.out.println("Enter Customer firstname");
			String firstName=scanner.next();
			System.out.println("Enter Customer lastname");
			String lastName=scanner.next();
			System.out.println("Enter  Customer  email id");
			String email=scanner.next();
			System.out.println("Enter  Customer  phone number");
			String phone=scanner.next();
			System.out.println("Enter  Customer PAN number");
			String pan=scanner.next();
			System.out.println("Enter  Customer  address");
			String address=scanner.next();
			CustomerBean customerBean=new CustomerBean();
			customerBean.setAddress(address);
			customerBean.setEmailId(email);
			customerBean.setPanNum(pan);
			customerBean.setPhoneNo(phone);
			customerBean.setFirstName(firstName);
			customerBean.setLastName(lastName);
			Random random=new Random();
			int cId=(int)(Math.random()*10000);
			customerBean.setcId(cId);	
			System.out.println("Enter balance to create account");
			double balance=scanner.nextDouble();
			AccountBean accountBean=new AccountBean();
			accountBean.setBalance(balance);
			accountBean.setInitialDeposit(balance);
			accountBean.setCustomerBean(customerBean);
			boolean result=service.createAccount(accountBean);
			if(result)
				System.out.println(" Account has been created ");
			else
			{
				System.out.println("Please Enter valid details ");
			}
               break;
		case 2:
			Scanner sc=new Scanner(System.in);
			CustomerBean customer=new CustomerBean();
			System.out.println("Enter Account ID");
			int accId=sc.nextInt();
			AccountBean accountBean1=service.findAccount(accId);
			System.out.println("Enter amount that you want to deposit");
			double depositAmt=sc.nextDouble();
			WalletTransaction wt=new WalletTransaction();
			wt.setTransactionType(1);
			wt.setTransactionDate(new Date());
			wt.setTransactionAmt(depositAmt);
			wt.setBeneficiaryAccountBean(null);
			accountBean1.addTransation(wt);
			if(accountBean1==null)
				System.out.println(" Account Does not Exist");
			boolean value=service.deposit(accountBean1, depositAmt);
			if(value){
				System.out.println("Deposited Money into Account ");
			}else{
				System.out.println("NOT Deposited Money into Account ");
			}
			

			break;

		case 3:
			Scanner sc1=new Scanner(System.in);
			System.out.println("Enter Account ID");
			int accId1=sc1.nextInt();
			AccountBean accountBean2=service.findAccount(accId1);
			System.out.println("Enter amount that you want to withdraw");
			double withdrawAmt=sc1.nextDouble();
			WalletTransaction wt1=new WalletTransaction();
			wt1.setTransactionType(2);
			wt1.setTransactionDate(new Date());
			wt1.setTransactionAmt(withdrawAmt);
			wt1.setBeneficiaryAccountBean(null);
			accountBean2.addTransation(wt1);
			if(accountBean2==null)
				System.out.println("Account Does not exist");
			boolean Value=service.withdraw(accountBean2, withdrawAmt);
			if(Value){
				System.out.println("Withdaw Money from Account done");
			}else{
				System.out.println("Withdaw Money from Account -Failed ");
			}
			
			break;
			
			
		case 4:
			System.out.println("Enter Account ID");
			Scanner s=new Scanner(System.in);
			int accId2=s.nextInt();
			AccountBean accountBean3=service.findAccount(accId2);
			if(accountBean3==null){
				System.out.println("Account Does not exist");
				return ;
			}
			
			double balance1=accountBean3.getBalance();
			System.out.println("Your balance is: " +balance1);

			   break;
		case 5:
			System.out.println("Enter Account ID to Transfer Money From");
			Scanner s1=new Scanner(System.in);
			int srcAccId=s1.nextInt();
			AccountBean accountBean4=service.findAccount(srcAccId);
			System.out.println("Enter Account ID to Transfer Money to");
			int targetAccId=s1.nextInt();
			AccountBean accountBean5=service.findAccount(targetAccId);
			System.out.println("Enter amount that you want to transfer");
			double transferAmt=s1.nextDouble();
			WalletTransaction wt2=new WalletTransaction();
			wt2.setTransactionType(3);
			wt2.setTransactionDate(new Date());
			wt2.setTransactionAmt(transferAmt);
			wt2.setBeneficiaryAccountBean(accountBean5);
			accountBean4.addTransation(wt2);
			boolean res=service.fundTransfer(accountBean4, accountBean5, transferAmt);
			
			if(res){
				System.out.println("Transfering Money from Account done");
			}else{
				System.out.println("Transfering Money from Account Failed ");
			}

			break;
		case 6:
			
			System.out.println("Enter Account ID (for printing Transaction Details");
			Scanner s2=new Scanner(System.in);
			
			int accId3=s2.nextInt();
			
			AccountBean accountBean6=service.findAccount(accId3);
			
			List<WalletTransaction>  transactions=accountBean6.getAllTransactions();
			
			System.out.println(accountBean6);
			System.out.println(accountBean6.getCustomerBean());
			System.out.println("Your Transcations are:");
			
			
			for(WalletTransaction wt3:transactions){
				
				String str="";
				if(wt3.getTransactionType()==1){
					str=str+"DEPOSIT";
				}
				if(wt3.getTransactionType()==2){
					str=str+"WITHDRAW";
				}
				if(wt3.getTransactionType()==3){
					str=str+"FUND TRANSFER";
				}
				
				str=str+"\t\t"+wt3.getTransactionDate();
				
				str=str+"\t\t"+wt3.getTransactionAmt();
				System.out.println(str);
			}

			break;
		case 7:System.exit(0);

			break;
			
			
		default:System.out.println("invalid option");
			break;
		}
		
	
		}
	}
}
