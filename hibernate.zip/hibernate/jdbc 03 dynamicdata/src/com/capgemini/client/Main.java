package com.capgemini.client;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.mysql.jdbc.PreparedStatement;

public class Main 
{
	public static Connection createConnection() throws ClassNotFoundException, SQLException {
		Class.forName("com.mysql.jdbc.Driver");
		String dbURL="jdbc:mysql://localhost:3306/demodb";
		String userName="root";
		String password="pass";
		Connection connection=DriverManager.getConnection(dbURL, userName, password);
		return connection;
	}
	
	public static void insertRecord() throws ClassNotFoundException, SQLException
	{
		Connection connection=createConnection();
		String SQL1="insert into customer values(?,?,?,?)";
		int inp_id=0;
		String inp_city="";
		double inp_amt=0;
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the id");
		inp_id=scan.nextInt();
		System.out.println("enter the name");
		scan.nextLine();
		String inp_name=scan.nextLine();
		System.out.println("enter the city");
		inp_city=scan.nextLine();
		System.out.println("enter the amount");
		inp_amt=scan.nextDouble();
		
		PreparedStatement statement =(PreparedStatement) connection.prepareStatement(SQL1);
		statement.setInt(1,inp_id);
		statement.setString(2, inp_name);
		statement.setString(3, inp_city);
		statement.setDouble(4, inp_amt);
		
		System.out.println(statement);
		statement.execute();
		System.out.println("inserted row");
		scan.close();
		statement.close();
		connection.close();
	}
	
	
	public static void updateRecord() throws ClassNotFoundException, SQLException
	{
		Connection connection=createConnection();
		String SQL1="update customer set C_amt=C_amt+?,C_city=? where C_id=?";
		
		System.out.println("enter the amount and id ");
		Scanner scan=new Scanner (System.in);
		double amount=scan.nextDouble();
		int id=scan.nextInt();
		String city=scan.next();
		PreparedStatement statement=(PreparedStatement) connection.prepareStatement(SQL1);
		statement.setInt(3,id);
		statement.setDouble(1, amount);
		statement.setString(2, city);
		statement.execute();
		scan.close();
		System.out.println("row updated");
		statement.close();
	}
	
	public static void deleteRecord() throws ClassNotFoundException, SQLException
	{
		Connection connection=createConnection();
		String SQL1="delete from customer where C_id=?";
		Scanner scan=new Scanner(System.in);
		System.out.println("enter id to delete");
		int id=scan.nextInt();
		PreparedStatement statement=(PreparedStatement) connection.prepareStatement(SQL1);
		statement.setInt(1, id);
		statement.execute();
		System.out.println("row deleted");
		scan.close();
		statement.close();
		connection.close();
	}
	
	public static void displayAll() throws ClassNotFoundException, SQLException
	{
		Connection connection=createConnection();
		String SQL1="select * from customer";
		
		Statement statement =connection.createStatement();
		ResultSet rs=statement.executeQuery(SQL1);
		while(rs.next()){
		System.out.println(rs.getInt(1) +" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getDouble(4));
		}
		rs.close();
		//System.out.println("row fetched");
		statement.close();
		connection.close();
	}
	
	public static void displayOneRecord(int id) throws ClassNotFoundException, SQLException
	{
		Connection connection=createConnection();
		String SQL1="select * from customer where C_id=?";
		
		PreparedStatement statement=(PreparedStatement) connection.prepareStatement(SQL1);
		System.out.println("entet the id");
		/*Scanner scan=new Scanner(System.in);
		int id=scan.nextInt();*/
		statement.setInt(1, id);
		System.out.println("display");
		ResultSet rs=statement.executeQuery();
		rs.next();
		System.out.println(rs.getInt(1) +" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getDouble(4));
		//System.out.println("row fetched");
		statement.close();
		/*scan.close();*/
		connection.close();
	}
	
	public static void main(String[] args) throws ClassNotFoundException, SQLException              
	{
		Scanner scan=new Scanner(System.in);
		int id=scan.nextInt();
		displayOneRecord(id);
		scan.close();
	}
}
