package com.capgemini.ui;

import java.sql.SQLException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.bussiness.Customer;
import com.capgemini.db.CustomerDAO;
import com.capgemini.db.CustomerDAOImp;

public class Main {
	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		System.out.println("customer application");
		System.out
				.println("---------------------------------------------------------");
		System.out.println("1) add new customer");
		System.out.println("2) update customer");
		System.out.println("3) display all customer");
		System.out.println("4) delete customer");
		System.out.println("5) exit");
		Scanner scan = new Scanner(System.in);
		System.out.println("enter the option ");
		int choice = scan.nextInt();
		switch (choice) 
		{
			case 1:
				add();
				break;
			case 2:
				update();
				break;
			case 3:
				display();
				break;
			case 4:
				remove();
				break;
			case 5:
				System.out.println("thank you!!!!!!!!!!!!!");
				System.exit(0);
				break;
			default:
				System.out.println("entered wrong option!");
				break;
		}
		scan.close();
	}
	public static void add() throws ClassNotFoundException, SQLException
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the name");
		String name=scan.next();
		System.out.println("enter the id");
		int id=scan.nextInt();
		System.out.println("enter the city");
		String city=scan.next();
		System.out.println("enter the amount");
		double amount=scan.nextDouble();
		Customer bean=new Customer();
		bean.setId(id);
		bean.setName(name);
		bean.setCity(city);
		bean.setOutStandingBalance(amount);
		scan.close();
		CustomerDAO dao=new CustomerDAOImp();
		if(dao.addCustomer(bean))
			System.out.println("created");
		else
			System.out.println("not created");
	}

	public static void update() throws ClassNotFoundException, SQLException
	{
		System.out.println("enter the id to update");
		Scanner scan=new Scanner(System.in);
		int id=scan.nextInt();
		Customer bean=new Customer();
		System.out.println("enter the name");
		String name=scan.next();
		System.out.println("enter the city");
		String city=scan.next();
		System.out.println("enter the amount");
		double amount=scan.nextDouble();
		bean.setId(id);
		bean.setName(name);
		bean.setCity(city);
		bean.setOutStandingBalance(amount);
		CustomerDAO dao=new CustomerDAOImp();
		if(dao.updateCustomer(bean))
			System.out.println("update done");
		else
			System.out.println("not updated");
		scan.close();
	}
	public static void display() throws ClassNotFoundException, SQLException
	{
		CustomerDAO customerDao=new CustomerDAOImp();
		List<Customer> list=customerDao.getAll();
		for (Customer customer : list) 
		{
			System.out.println(customer);
		}
	}
	public static void remove() throws ClassNotFoundException, SQLException
	{
		Scanner scan=new Scanner(System.in);
		System.out.println("enter the id");
		int id=scan.nextInt();
		scan.close();
		CustomerDAO customerDao=new CustomerDAOImp();
		boolean result=customerDao.removeCustomer(id);
		if(result)
			System.out.println("successfully deleted");
		else
			System.out.println("not deleted");
	}
	
}
