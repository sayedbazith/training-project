package com.capgemini.bussiness;

public class Customer 
{
	private int id;
	private String name;
	private String city;
	private double outStandingBalance;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		if(id<=0)
		{
			throw new RuntimeException("Invalid id");
		}
		else
			this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public double getOutStandingBalance() {
		return outStandingBalance;
	}
	public void setOutStandingBalance(double outStandingBalance) {
		this.outStandingBalance = outStandingBalance;
	}
	
	public String getCustomerRating()
	{
		if(this.outStandingBalance<5000)
			return "GOOD";
		else
			return "NORMAL";
	}
	
	@Override
	public String toString() {
		return "Customer [id=" + id + ", name=" + name + ", city=" + city
				+ ", outStandingBalance=" + outStandingBalance + "]";
	}
	
}
