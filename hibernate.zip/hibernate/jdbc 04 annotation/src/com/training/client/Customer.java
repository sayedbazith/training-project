package com.training.client;

@Table(name = "Customer")
@Entity

public class Customer {
	@Id
	int id;
	
	@Column(name = "C_name", notNull = true, size = 25)
	String name;
	
	@City(city = "C_city", size = 20)
	String city;
	double outStandingAmount;
}
