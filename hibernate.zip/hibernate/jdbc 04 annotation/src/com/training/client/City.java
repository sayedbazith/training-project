package com.training.client;

public @interface City {
	
	String city();
	int size();
}
