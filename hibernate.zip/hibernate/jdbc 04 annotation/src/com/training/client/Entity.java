package com.training.client;

public @interface Entity {

	
}
