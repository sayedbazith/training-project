package com.training.client;

/**
 @author basayed
 
*/
public class Test4 {

	/**
	@param n is  the value of side of the square
	*/
	int square(int n)
	{
		return n*n;
	}
}
