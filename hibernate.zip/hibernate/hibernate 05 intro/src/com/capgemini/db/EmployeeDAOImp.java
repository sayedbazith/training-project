package com.capgemini.db;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import javax.persistence.Query;

import com.capgemini.business.Employee;

public class EmployeeDAOImp implements IEmployeeDAO {

	@Override
	public boolean addEmp(Employee employee) {
		// TODO Auto-generated method stub
		boolean isValid=false;
		try
		{
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager em=emf.createEntityManager();
			EntityTransaction et=em.getTransaction();
			Employee emp=new Employee();
			et.begin();
			em.persist(emp);
			et.commit();
			em.close();
			emf.close();
			isValid=true;
		}
		catch(Exception e)
		{
			isValid=false;
		}
		return isValid;
	}

	@Override
	public boolean removeEmp(int id) {
		// TODO Auto-generated method stub
		boolean isValid=false;
		try
		{
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager em=emf.createEntityManager();
		
			Employee emp=em.find(Employee.class, id);
			em.getTransaction().begin();
			em.remove(emp);
			em.getTransaction().commit();
			em.close();
			emf.close();
			isValid=true;
		}
		catch(Exception e)
		{
			isValid=false;
		}
		return isValid;
	}

	@Override
	public boolean updateEmp(Employee employee) {
		// TODO Auto-generated method stub
		boolean isValid=false;
		try
		{
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager em=emf.createEntityManager();
		
			Employee emp=em.find(Employee.class, employee.getEmpId());
			em.getTransaction().begin();
			em.merge(emp);
			em.getTransaction().commit();
			em.close();
			emf.close();
			isValid=true;
		}
		catch(Exception e)
		{
			isValid=false;
		}
		return isValid;
	}

	@Override
	public Employee findEmp(int id) {
		// TODO Auto-generated method stub
		Employee employee=null;
		try
		{
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager em=emf.createEntityManager();
		
			Employee emp=em.find(Employee.class, id);
			employee=emp;
			em.close();
			emf.close();
			
		}
		catch(Exception e)
		{
			employee=null;
		}
		return employee;
	}

	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		List<Employee> list=new ArrayList<Employee>();
		try
		{
			EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
			EntityManager em=emf.createEntityManager();
			String query="from Employee";
			Query qr=em.createQuery(query);
			list=qr.getResultList();
			em.close();
			emf.close();
			
		}
		catch(Exception e)
		{
			list=null;
		}
		return list;
	}

}
