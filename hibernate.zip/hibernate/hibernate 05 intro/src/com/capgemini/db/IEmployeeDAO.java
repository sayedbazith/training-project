package com.capgemini.db;

import java.util.List;

import com.capgemini.business.Employee;

public interface IEmployeeDAO {
	boolean addEmp(Employee employee);
	boolean removeEmp(int id);
	boolean updateEmp(Employee employee);
	Employee findEmp(int id);
	List<Employee> getAllEmployee();
}
