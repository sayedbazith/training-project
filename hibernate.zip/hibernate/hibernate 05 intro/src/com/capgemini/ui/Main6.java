package com.capgemini.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.business.Contact;

public class Main6 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		EntityManagerFactory efm=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=efm.createEntityManager();
		em.getTransaction().begin();
		Contact contact4=new Contact();
	}

}
