package com.capgemini.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;
import com.capgemini.business.Employee;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		
		Employee e=new Employee();
		e.setEmpId(102);
		e.setEmpName("bazith");
		e.setEmpGender('M');
		e.setBasicSalary(15000);
		e.setEmpGrade('A');
		
		EntityTransaction t=em.getTransaction();
		t.begin();

		em.persist(e);
		
		t.commit();
		
		em.close();
		emf.close();
		System.out.println("object is stored");
		
	}

}
