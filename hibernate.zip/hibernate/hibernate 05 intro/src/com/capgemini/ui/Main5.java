package com.capgemini.ui;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.capgemini.business.Contact;

public class Main5 
{

	public static void main(String[] args)
	{
		// TODO Auto-generated method stub
		Contact contact1=new Contact(101,"rafi","8886385538");
		Contact contact2=new Contact(102,"bazith","9492476179");
		Contact contact3=new Contact(103,"sayed","9542724356");
		Contact contact4=new Contact();
		EntityManagerFactory efm=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=efm.createEntityManager();
		
		//em.persist(contact1);
		//em.persist(contact2);
		//em.persist(contact3);
		//em.getTransaction().commit();
		//contact1.setPhoneNumber("9951289768");
		
		
		
		
		contact4=em.find(Contact.class, 101);
		contact4.setPhoneNumber("8886385538");
		em.getTransaction().begin();
		em.merge(contact4);
		em.getTransaction().commit();
		System.out.println(contact1.equals(contact4));
		em.close();
		efm.close();
	}

}
