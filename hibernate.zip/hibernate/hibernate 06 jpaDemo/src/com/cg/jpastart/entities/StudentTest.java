package com.cg.jpastart.entities;


import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class StudentTest {

	public static void main(String[] args) {
		
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em = factory.createEntityManager();
		
		
		System.out.println("creating a bean ..");
		
		/*Student student = new Student();
		student.setName("rafi");*/
		//why id has not been set
		//ans : we have chosen it to be auto generated 
		
		/*em.persist(student); //insert 
		em.getTransaction().commit(); //pesist has to be given within a transaction
*/		em.getTransaction().begin();
		System.out.println("Added one student to database.");
		String str="from Student";
		Query qu=em.createQuery(str);
		List<Student> list=qu.getResultList();
		for (Student student2 : list) {
			
			student2=em.find(Student.class, student2.getStudentId());
			student2.setName(student2.getName().toUpperCase());
			em.merge(student2);
			
		}
		/*
		Student s=new Student();
		s.setName("asdfasdf");
		em.persist(s);*/
		em.getTransaction().commit();
		/*
		Student s=new Student();
		s=em.find(Student.class, 2);
		em.getTransaction().begin();
		em.remove(s);*/
		
		
		
		
		
		
		
		em.close();
		factory.close();
	}
}
