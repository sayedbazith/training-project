package com.cg.jpastart.entities;

import javax.persistence.Embeddable;

@Embeddable
public class SeatInfo {
	private int totalCount;
	private int availableCount;
	private int bookcount;
	
	public int getTotalCount() {
		return totalCount;
	}
	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}
	public int getAvailableCount() {
		return availableCount;
	}
	public void setAvailableCount(int availableCount) {
		this.availableCount = availableCount;
	}
	public int getBookcount() {
		return bookcount;
	}
	public void setBookcount(int bookcount) {
		this.bookcount = bookcount;
	}
	
	public SeatInfo() {
		super();
	}
	
	public SeatInfo(int totalCount, int availableCount, int bookcount) {
		super();
		this.totalCount = totalCount;
		this.availableCount = availableCount;
		this.bookcount = bookcount;
	}
	@Override
	public String toString() {
		return "SeatInfo [totalCount=" + totalCount + ", availableCount="
				+ availableCount + ", bookcount=" + bookcount + "]";
	}
	
}
