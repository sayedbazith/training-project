package com.capg.bankapp.exception;

public class AccountException extends Exception {

	public AccountException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AccountException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	
	
	
}
