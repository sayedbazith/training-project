package com.capg.bankapp.bean;

public class Account {

	private String PhoneNumber;
	private double balance;

	// TODO Auto-generated constructor stub

	
	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getPhoneNumber() {
		return PhoneNumber;
	}

	public void setPhoneNumber(String phoneNumber) {
		PhoneNumber = phoneNumber;
	}

}
