package com.capgemini.payment.bean;

import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class CustomerBean {
	
	private String customerName;
	private int customerAge;
	@Id
	private String accountNumber;
	private double customerBalance;
	/*private TranscationBean transcationBean;*/
	
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	/*public TranscationBean getTranscationBean() {
		return transcationBean;
	}
	public void setTranscationBean(TranscationBean transcationBean) {
		this.transcationBean = transcationBean;
	}*/
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getCustomerAge() {
		return customerAge;
	}
	public void setCustomerAge(int customerAge) {
		this.customerAge = customerAge;
	}
	
	public double getCustomerBalance() {
		return customerBalance;
	}
	public void setCustomerBalance(double customerBalance) {
		this.customerBalance = customerBalance;
	}
	@Override
	public String toString() {
		return "CustomerBean [customerName=" + customerName + ", customerAge="
				+ customerAge + ", accountNumber=" + accountNumber
				+ ", customerBalance=" + customerBalance + "]";
	}
	
	/*@Override
	public String toString() {
		return "CustomerBean [customerName=" + customerName + ", customerAge="
				+ customerAge + ", accountNumber=" + accountNumber
				+ ", customerBalance=" + customerBalance + ", transcationBean="
				+ transcationBean + "]";
	}*/
	
	
	
	
	
	
	
}
