package com.capgemini.payment.bean;

import java.util.Date;

public class TranscationBean {

	private String number;
	private double deposit;
	private double withdrawl;
	private String transcationType;
	private Date transcationTime;

	

	public String getNumber() {
		return number;
	}

	public void setNumber(String number) {
		this.number = number;
	}

	public double getDeposit() {
		return deposit;
	}

	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}

	public double getWithdrawl() {
		return withdrawl;
	}

	public void setWithdrawl(double withdrawl) {
		this.withdrawl = withdrawl;
	}

	

	public Date getTranscationTime() {
		return transcationTime;
	}

	public void setTranscationTime(Date transcationTime) {
		this.transcationTime = transcationTime;
	}

	
	public String getTranscationType() {
		return transcationType;
	}

	public void setTranscationType(String transcationType) {
		this.transcationType = transcationType;
	}

	@Override
	public String toString() {
		return "TranscationBean [number=" + number + ", deposit=" + deposit
				+ ", withdrawl=" + withdrawl + ", transcationType="
				+ transcationType + ", transcationTime=" + transcationTime
				+ "]";
	}

	

}
