package com.capgemini.payment.test;

import static org.junit.Assert.*;

import org.junit.Test;

import com.capgemini.payment.bean.CustomerBean;
import com.capgemini.payment.exception.PaymentException;
import com.capgemini.payment.service.IService;
import com.capgemini.payment.service.ServiceImp;

public class ServiceImpTest {
	
	IService service=new ServiceImp();
	
	@Test
	public void testValidateCreateAccount() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(2500);
		bean.setCustomerName("rafi");
		boolean result=service.validate(bean);
		assertTrue(result);
	}
	
	@Test(expected=PaymentException.class)
	public void testValidateNameNull() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(2500);
		bean.setCustomerName(null);
		service.validate(bean);
	}
	
	@Test(expected=PaymentException.class)
	public void testValidateAgeNull() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(1);
		bean.setCustomerBalance(2500);
		bean.setCustomerName(null);
		service.validate(bean);
	}
	
	@Test(expected=PaymentException.class)
	public void testValidateBalanceNegetive() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(-2500);
		bean.setCustomerName("rafi");
		service.validate(bean);
	}
	
	@Test(expected=PaymentException.class)
	public void testValidateNumberNegetive() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("888638");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(2500);
		bean.setCustomerName("rafi");
		service.validate(bean);
	}
	
	@Test
	public void testCreateAccount() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(2500);
		bean.setCustomerName("rafi");
		boolean result=service.createAccount(bean);
		assertTrue(result);
	}

	@Test(expected=PaymentException.class)
	public void testCreateAccountNegetive() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(2500);
		bean.setCustomerName(null);
		service.createAccount(bean);
	}	
	
	/*@Test
	public void testShowBalance() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(2500);
		bean.setCustomerName("rafi");
		service.createAccount(bean);
		CustomerBean result=service.showBalance("8886385544");
		assertNull(result);
	}*/

	@Test
	public void testPrintTranscations() {
		
	}

	@Test
	public void testDeposit() {
		
	}

	@Test
	public void testWithDraw() {
		
	}

	@Test
	public void testFundTransfer() {
		
	}

}
