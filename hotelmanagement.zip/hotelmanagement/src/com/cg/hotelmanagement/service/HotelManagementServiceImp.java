package com.cg.hotelmanagement.service;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.hotelmanagement.dao.IHotelManagementDAO;
import com.cg.hotelmanagement.entity.HotelEntity;

@Service
@Transactional
public class HotelManagementServiceImp implements IHotelManagementService {

	@Autowired
	IHotelManagementDAO dao;
	
	@Override
	public List<HotelEntity> retrive() {
		// TODO Auto-generated method stub
		return dao.retrive();
	}

}
