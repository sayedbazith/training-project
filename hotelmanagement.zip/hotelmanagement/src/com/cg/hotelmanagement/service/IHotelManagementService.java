package com.cg.hotelmanagement.service;

import java.util.List;

import com.cg.hotelmanagement.entity.HotelEntity;

public interface IHotelManagementService {
	
	List<HotelEntity> retrive();
}
