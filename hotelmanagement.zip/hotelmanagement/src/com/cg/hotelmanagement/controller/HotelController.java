package com.cg.hotelmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.hotelmanagement.entity.HotelEntity;
import com.cg.hotelmanagement.service.IHotelManagementService;

@Controller
public class HotelController {
	
	@Autowired
	IHotelManagementService service;
	List<HotelEntity> list=null;
	
	@RequestMapping(value="all")
	public ModelAndView home()
	{
		list=service.retrive();
		return new ModelAndView("home","data",list);
	}
	
	@RequestMapping(value="book")
	public ModelAndView booking(@RequestParam("name") String hotelName)
	{	
		return new ModelAndView("success","hotel",hotelName);
	}
	
}
