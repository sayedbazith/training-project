package com.cg.hotelmanagement.dao;

import java.util.List;

import com.cg.hotelmanagement.entity.HotelEntity;

public interface IHotelManagementDAO {
	
	List<HotelEntity> retrive();
}
