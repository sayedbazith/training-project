package com.cg.hotelmanagement.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.hotelmanagement.entity.HotelEntity;

@Repository
public class HotelManagementDAOImp implements IHotelManagementDAO {
	
	@PersistenceContext
	EntityManager em;
	
	List<HotelEntity> list=null;
	
	@Override
	public List<HotelEntity> retrive() {
		// TODO Auto-generated method stub
		
		Query query=em.createQuery("from HotelEntity");
		list=query.getResultList();
		return list;
	}

}
