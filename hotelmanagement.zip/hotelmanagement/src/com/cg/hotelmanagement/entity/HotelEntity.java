package com.cg.hotelmanagement.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class HotelEntity {
	@Id
	@Column
	private int hotelId;
	@Column
	private String hotelName;
	@Column
	private int hotelRating;
	@Column
	private double hotelRent;
	@Column
	private int hotelAvailableRooms;
	
	public HotelEntity() {
		super();
	}
	
	public HotelEntity(int hotelId, String hotelName, int hotelRating,
			double hotelRent, int hotelAvailableRooms) {
		super();
		this.hotelId = hotelId;
		this.hotelName = hotelName;
		this.hotelRating = hotelRating;
		this.hotelRent = hotelRent;
		this.hotelAvailableRooms = hotelAvailableRooms;
	}
	
	@Override
	public String toString() {
		return "HotelEntity [hotelId=" + hotelId + ", hotelName=" + hotelName
				+ ", hotelRating=" + hotelRating + ", hotelRent=" + hotelRent
				+ ", hotelAvailableRooms=" + hotelAvailableRooms + "]";
	}

	public int getHotelId() {
		return hotelId;
	}
	public void setHotelId(int hotelId) {
		this.hotelId = hotelId;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public int getHotelRating() {
		return hotelRating;
	}
	public void setHotelRating(int hotelRating) {
		this.hotelRating = hotelRating;
	}
	public double getHotelRent() {
		return hotelRent;
	}
	public void setHotelRent(double hotelRent) {
		this.hotelRent = hotelRent;
	}
	public int getHotelAvailableRooms() {
		return hotelAvailableRooms;
	}
	public void setHotelAvailableRooms(int hotelAvailableRooms) {
		this.hotelAvailableRooms = hotelAvailableRooms;
	}
}
