package com.cg.stepfiles;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class FormPageObject {
		
	WebDriver driver;
	
	@FindBy(name="txtFN")
	private WebElement fName;

	@FindBy(id="btnPayment")
	private WebElement button;

	@FindBy(name="gender")
	private WebElement gender;
	
	@FindBy(name="course")
	private WebElement course;

	@FindBy(name="place")
	private WebElement place;
	
	@FindBy(name="address")
	private WebElement address;
	
	@FindBy(name="mobile")
	private WebElement number;
	
	
	protected WebElement getNumber() {
		return number;
	}

	protected void setNumber(String number) {
		this.number.sendKeys(number);
	}

	protected WebElement getAddress() {
		return address;
	}

	protected void setAddress(String address) {
		this.address.sendKeys(address);
	}

	protected WebElement getPlace() {
		return place;
	}

	protected void setPlace(String place) {
		Select pla=new Select(driver.findElement(By.name("place")));
		pla.selectByVisibleText(place);
	}

	public WebElement getCourse() {
		return course;
	}

	public void setCourse(String course) {
		List<WebElement> cou=driver.findElements(By.name("course"));
		for (WebElement webElement : cou) {
			if(webElement.getAttribute("value").equalsIgnoreCase(course))
			{
				this.course=webElement;
				webElement.click();
			}
		}
	}

	public WebElement getGender() {
		return gender;
	}

	public void setGender(String gender) {
		List<WebElement> gen=driver.findElements(By.name("gender"));
		for (WebElement webElement : gen) {
			if(webElement.getAttribute("value").equalsIgnoreCase(gender))
			{
				webElement.click();
				this.gender=webElement;
			}
		}
	}

	public void setButton() {
		this.button.click();
		}

	public FormPageObject(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public FormPageObject() {
		super();
	}

	public WebElement getfName() {
		return fName;
	}

	public void setfName(String fName) {
		this.fName.sendKeys(fName);;
	}
}
