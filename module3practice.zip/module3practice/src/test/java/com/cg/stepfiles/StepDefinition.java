package com.cg.stepfiles;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.DataTable;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDefinition {

	WebDriver driver;
	FormPageObject bean;
	String name;
	String msg;
	WebElement chennai;

	@Given("^user is in register page$")
	public void user_is_in_register_page() {
		// Write code here that turns the phrase above into concrete actions
		System.setProperty("webdriver.chrome.driver",
				"C:\\Users\\Sayed Bazith\\Desktop\\bdd jar files\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("file:///C:/Users/Sayed%20Bazith/Desktop/practice.html");
		bean = new FormPageObject(driver);
	}

	@When("^user enters the firstname$")
	public void user_enters_the_firstname(DataTable arg1) throws Exception {
		// Write code here that turns the phrase above into concrete actions
		// For automatic transformation, change DataTable to one of
		// List<YourType>, List<List<E>>, List<Map<K,V>> or Map<K,V>.
		// E,K,V must be a scalar (String, Integer, Date, enum etc)
		List<String> list = arg1.asList(String.class);
		for (String string : list) {
			if (string.matches("[A-Za-z]{5,17}")) {
				bean.getfName().clear();
				bean.setfName(string);
				bean.setButton();
			} else {
				bean.getfName().clear();
				bean.setfName(string);
				bean.setButton();
				Thread.sleep(2000);
				msg = driver.switchTo().alert().getText();
				driver.switchTo().alert().accept();
				System.out.println(msg);
			}
		}
	}

	@Then("^display the names$")
	public void display_the_names() {
		// Write code here that turns the phrase above into concrete actions
		driver.close();
	}

	@When("^user select male$")
	public void user_select_male() throws Exception {
		// Write code here that turns the phrase above into concrete actions
		bean.setfName("bazith");
		bean.setGender("Male");
		Thread.sleep(2000);
		bean.setButton();
		msg=driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
	}

	@Then("^select male option$")
	public void select_male_option() {
		// Write code here that turns the phrase above into concrete actions
		System.out.println(bean.getGender().getAttribute("value"));
		driver.close();
	}

	@When("^user not selected gender option$")
	public void user_not_selected_gender_option() throws Exception {
	    // Write code here that turns the phrase above into concrete actions
		bean.setfName("bazith");
		bean.setGender("");
		bean.setButton();
		msg=driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	}

	@Then("^display alert gender alert$")
	public void display_alert_gender_alert()  {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println(msg);
		driver.close();
	}
	
	@When("^user select the course option$")
	public void user_select_the_course_option() throws Exception  {
	    // Write code here that turns the phrase above into concrete actions
	    bean.setfName("mounika");
	    bean.setGender("Female");
	    bean.setCourse("M.Tech");
	    Thread.sleep(2000);
	    bean.setButton();
	    msg=driver.switchTo().alert().getText();
	    driver.switchTo().alert().accept();
	}

	@Then("^display course name$")
	public void display_course_name()  {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println(bean.getCourse().getAttribute("value"));
	    driver.close();
	}
	
	@When("^user not selecting the course$")
	public void user_not_selecting_the_course() throws Exception  {
	    // Write code here that turns the phrase above into concrete actions
	   bean.setfName("bazith");
	   bean.setGender("male");
	   bean.setButton();
	   msg=driver.switchTo().alert().getText();
	   Thread.sleep(2000);
	   driver.switchTo().alert().accept();
	}

	@Then("^display course alert$")
	public void display_course_alert()  {
	    // Write code here that turns the phrase above into concrete actions
	   System.out.println(msg);
		driver.close();
	}
	
	@When("^user select the place$")
	public void user_select_the_place() {
	    // Write code here that turns the phrase above into concrete actions
		bean.setfName("bazith");
		bean.setGender("male");
		bean.setCourse("b.tech");
		bean.setPlace("vizag");
		bean.setButton();
		msg=driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
		
	}

	@Then("^display the place$")
	public void display_the_place()  {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println(bean.getPlace().getAttribute("value"));
	    driver.close();
	}

	@When("^user not selecting the place$")
	public void user_not_selecting_the_place() throws Exception  {
	    // Write code here that turns the phrase above into concrete actions
		bean.setfName("bazith");
		bean.setGender("male");
		bean.setCourse("b.tech");
		bean.setPlace("select place");
		bean.setButton();
		Thread.sleep(2000);
		msg=driver.switchTo().alert().getText();
		Thread.sleep(2000);
		driver.switchTo().alert().accept();
	}

	@Then("^display the palce alert$")
	public void display_the_palce_alert()  {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println(msg);
	    driver.close();
	}
	
	@When("^user entering the address$")
	public void user_entering_the_address() throws Exception  {
	    // Write code here that turns the phrase above into concrete actions
		bean.setfName("bazith");
		bean.setGender("male");
		bean.setCourse("b.tech");
		bean.setPlace("hyderabad");
		bean.setAddress("sipcot");
		Thread.sleep(2000);
		bean.setButton();
		driver.switchTo().alert().accept();
	}

	@Then("^display the address$")
	public void display_the_address()  {
	    // Write code here that turns the phrase above into concrete actions
	  System.out.println(bean.getAddress().getAttribute("value"));
	  driver.close();
	}

	@When("^user not entering the address$")
	public void user_not_entering_the_address()  {
	    // Write code here that turns the phrase above into concrete actions
		bean.setfName("bazith");
		bean.setGender("male");
		bean.setCourse("b.tech");
		bean.setPlace("hyderabad");
		bean.setAddress("");
		bean.setButton();
		msg=driver.switchTo().alert().getText();
		driver.switchTo().alert().accept();
	}
	
	@Then("^display address alert$")
	public void display_address_alert()  {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println(msg);
		driver.close();
	}
	
	@When("^user enters the (\\d+) number$")
	public void user_enters_the_number(Integer arg1) throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		bean.setfName("bazith");
		bean.setGender("male");
		bean.setCourse("b.tech");
		bean.setPlace("hyderabad");
		bean.setAddress("sipcot");
		bean.setNumber(arg1.toString());
		bean.setButton();
		driver.switchTo().alert().accept();
	}

	@Then("^display the mobile number$")
	public void display_the_mobile_number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    System.out.println(bean.getNumber().getAttribute("value"));
	    driver.close();
	}
}
