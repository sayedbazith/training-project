package com.capg.wallet.test;




import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;

import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.wallet.bean.WalletBean;
import com.capg.wallet.exception.WalletException;
import com.capg.wallet.service.IWalletService;
import com.capg.wallet.service.WalletServiceImp;

public class WalletTest {
	private static IWalletService service = null;

	@BeforeClass
	public static void wallet() {
		
		service=new WalletServiceImp();
		
	
	}
	@Test
	public void testFundTransferPhNo2() throws WalletException {
		
		WalletBean bean=new WalletBean();
		bean.setPh1("9032974524");
		bean.setAmount(500);
		bean.setPh2("1234567892");
		
		boolean result=service.fundTransfer(bean);
		assertFalse(result);
		
	}
	
	@Test
	public void testFundTransferPhNo1() throws WalletException {
		
		WalletBean beanTest=new WalletBean();
		beanTest.setPh1("12345678900");
		beanTest.setAmount(500);
		beanTest.setPh2("9032974524");
		beanTest.setBalance(10000);
		
		boolean result=service.fundTransfer(beanTest);
		assertFalse(result);
		
	}
	@Test
	public void testFundTransferForPositive() throws WalletException {
		
		WalletBean beanTest=new WalletBean();
		beanTest.setPh1("9032974524");
		beanTest.setAmount(3000.00);
		beanTest.setPh2("9901988280");
		beanTest.setBalance(10000.00);	
		
		boolean result=service.fundTransfer(beanTest);
		assertTrue(result);
		
	}
	
}
