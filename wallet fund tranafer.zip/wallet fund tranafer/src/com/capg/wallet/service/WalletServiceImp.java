package com.capg.wallet.service;

import com.capg.wallet.bean.WalletBean;
import com.capg.wallet.dao.IWalletDao;
import com.capg.wallet.dao.WalletDaoImp;
import com.capg.wallet.exception.ExceptionMessage;
import com.capg.wallet.exception.WalletException;

public class WalletServiceImp implements IWalletService {
	  IWalletDao dao = new WalletDaoImp();
	  WalletBean bean=new WalletBean();

	@Override
	public boolean deposit(WalletBean bean) {
		
		return dao.deposit(bean);
	}

	@Override
	public boolean withdraw(WalletBean bean) {
		
		return dao.withdraw(bean);
	}

	@Override
	public boolean fundTransfer(WalletBean bean) throws WalletException {
		
		return dao.fundTransfer(bean);
	}
		
	public boolean validatePhNo(WalletBean bean) throws WalletException{
		
		boolean result=true;
		
		if(!(bean.getPh1().length()==10) && !(bean.getPh2().length()==10) && !(bean.getPh1().matches("[6-9][0-9]{9}")) &&!(bean.getPh2().matches("[6-9][0-9]{9}")) )
		{
			result=false;
			throw new WalletException(ExceptionMessage.ERROR3);
		}
		
		return result;
			
		
	}
}
