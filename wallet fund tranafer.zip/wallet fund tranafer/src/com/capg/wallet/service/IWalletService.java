package com.capg.wallet.service;

import com.capg.wallet.bean.WalletBean;
import com.capg.wallet.exception.WalletException;

public interface IWalletService {

	public boolean deposit(WalletBean bean) ;
	public boolean withdraw(WalletBean bean);
	boolean fundTransfer(WalletBean bean) throws WalletException;
	public boolean validatePhNo(WalletBean bean) throws WalletException;

}
