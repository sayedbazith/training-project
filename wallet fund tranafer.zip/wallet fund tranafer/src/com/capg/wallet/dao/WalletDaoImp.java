package com.capg.wallet.dao;

import java.security.Provider.Service;
import java.util.ArrayList;

import com.capg.wallet.bean.WalletBean;
import com.capg.wallet.exception.ExceptionMessage;
import com.capg.wallet.exception.WalletException;
import com.capg.wallet.service.IWalletService;
import com.capg.wallet.service.WalletServiceImp;

public class WalletDaoImp implements IWalletDao {

	ArrayList<WalletBean> list = new ArrayList<WalletBean>();
	
	
	public void addAccount() {

		WalletBean b1 = new WalletBean();
		b1.setPh1("9032974524");
		b1.setBalance(5000);
		list.add(b1);
		WalletBean b2 = new WalletBean();
		b2.setPh1("9901988280");
		b2.setBalance(5000);
		list.add(b2);

	}

	@Override
	public boolean deposit(WalletBean bean) {
		

		boolean b = false;

		for (WalletBean bean2 : list) {

			
			if (bean2.getPh2() == bean.getPh1()) {

				double bal1 = bean.getBalance() + bean.getAmount();
				b = true;
				bean2.setBalance(bal1);
				System.out.println(bal1);
				break;

			}

		}

		return b;
	}

	@Override
	public boolean withdraw(WalletBean bean) {
		
		
		boolean b1 = false;

		for (WalletBean bean2 : list) {
			if (bean2.getPh1() == bean.getPh1()) {
				if (bean2.getBalance() > bean.getAmount()) {
					bean2.setBalance(bean.getBalance() - bean.getAmount());
					
					b1 = true;
					break;
				}

			}
		}

		return b1;
	}

	@Override
	public boolean fundTransfer(WalletBean bean)throws WalletException {
		addAccount();
		boolean b2 = false;
		IWalletService service=new WalletServiceImp();
		boolean match=service.validatePhNo(bean);
		System.out.println("match"+match);
		
		
   if(match)
   {
	   System.out.println(bean.getBalance());
	   for (WalletBean bean2 : list) {
			System.out.println("hii");
			try {
				if (bean.getPh2().equals(bean2.getPh1()))
				{
					
					boolean with = withdraw(bean);
					System.out.println("withdraw");
					if (with) {
						boolean dep = deposit(bean);
						System.out.println("deposit");
						if (dep) {
							b2 = true;
							System.out.println("transfered");

						}

					}
				}
			} catch (Exception e) {
				System.out.println(e.getMessage());
			}

		}

   }	
	
	System.out.println(b2);
	return b2;
	}
}
