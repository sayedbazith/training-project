package com.capg.wallet.dao;

import com.capg.wallet.bean.WalletBean;
import com.capg.wallet.exception.WalletException;

public interface IWalletDao {
	public boolean deposit(WalletBean bean) ;
	public boolean withdraw(WalletBean bean);
	boolean fundTransfer(WalletBean bean) throws WalletException;
	
}