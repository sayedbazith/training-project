package com.capg.wallet.ui;

import com.capg.wallet.bean.WalletBean;
import com.capg.wallet.exception.WalletException;
import com.capg.wallet.service.IWalletService;
import com.capg.wallet.service.WalletServiceImp;

public class Cust {

	public static void main(String[] args) throws WalletException {

		IWalletService service = new WalletServiceImp();
		WalletBean bean = new WalletBean();
		double amount = 5000;
		double balance = 15000;
		String ph1 = "9032974524";
		String ph2 = "9901988280";
		bean.setAmount(amount);
		bean.setBalance(balance);
		bean.setPh1(ph1);
		bean.setPh2(ph2);
		/*boolean b = service.fundTransfer(ph1, balance, amount, ph2);
		if (b) 
		{
			
			boolean b1=service.deposit(ph1, amount);
			if(b1){
				service.withdraw(ph1, balance, amount);
				System.out.println("ok");
			
			}
		}
		else
			System.out.println("client");
	}
*/
}
}
