package com.capg.wallet.exception;

public class ExceptionMessage {
	
	
	public static final String ERROR1 = "inadequate balance";
	public static final String ERROR2 = "amount should be a positive value";
	public static final String ERROR3 = "amount should be a positive value";
	public static final String ERROR4 = "Phone number Should not be null";
	public static final String ERROR5 = "Enter Valid Phnum";



}
