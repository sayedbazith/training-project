package com.cg.springmvc.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.springframework.stereotype.Repository;

import com.cg.springmvc.dto.Employee;

@Repository("dao")
public class EmployeeDaoImpl implements IEmployeeDao {

	@PersistenceContext
	EntityManager em;
	
	@Override
	public int addEmployeeData(Employee emp) {
		
		em.persist(emp);
		em.flush();
		return emp.getEmpId();
	}

	@Override
	public List<Employee> showAllEmployee() {
		
		Query query=em.createQuery("from Employee");
		List<Employee> myList=query.getResultList();
		return myList;
	}

	@Override
	public void deleteEmployee(int empId) {
		
		Query query=em.createQuery("delete from Employee where empId=:eid");
		query.setParameter("eid", empId);
		query.executeUpdate();
	}

	@Override
	public void updateEmployee(Employee emp) {
		
		//Query query=em.createQuery("update table employee")
		
	}

	@Override
	public Employee searchEmployee(int id) {
		return null;
	}

}
