package com.cg.spring.currency;

import java.util.ArrayList;

public interface ICurrencyList {
	ArrayList<String> getCurrList();
}
