package com.cg.spring.currency;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext factory=new ClassPathXmlApplicationContext("currencyList.xml");
		ICurrencyList currencyBean=(ICurrencyList) factory.getBean("currencyBean");
		List list=currencyBean.getCurrList();
		System.out.println(list);
	}

}
