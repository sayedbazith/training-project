package com.cg.spring.currency;

import java.util.ArrayList;

public class CurrencyListImpl implements ICurrencyList {

	ArrayList<String> currencyList=null;


	public void setCurrencyList(ArrayList<String> currencyList) {
		this.currencyList = currencyList;
	}

	public ArrayList<String> getCurrList() {
		// TODO Auto-generated method stub
		return currencyList;
	}

	
}
