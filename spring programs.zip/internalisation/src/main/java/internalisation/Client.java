package internalisation;

import java.util.Locale;

import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {
	public static void main(String[] args) {
		ApplicationContext factory=new ClassPathXmlApplicationContext("user.xml");
		MessageSource message=(MessageSource) factory.getBean("messageSource");
		Locale local=new Locale("In","HN");
		String msg=message.getMessage("welcome.message", null, local);
		System.out.println(msg);
	}
}
