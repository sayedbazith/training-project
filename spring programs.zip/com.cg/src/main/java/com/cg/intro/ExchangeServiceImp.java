package com.cg.intro;

public class ExchangeServiceImp implements IExchangeService {
	
	private double exchangeRate;
	
	public ExchangeServiceImp(double exchangeRate) {
		System.out.println("ExchangeServiceImp");
		this.exchangeRate = exchangeRate;
	}

	public double getExchangeRate() {
		// TODO Auto-generated method stub
		System.out.println("getexchangeRate()");
		return exchangeRate;
	}

	public ExchangeServiceImp() {
		super();
	}

}
