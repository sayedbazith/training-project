package com.cg.intro;

public interface IExchangeService {
	public double getExchangeRate();
}
