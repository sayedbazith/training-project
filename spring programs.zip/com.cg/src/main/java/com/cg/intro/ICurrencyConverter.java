package com.cg.intro;

public interface ICurrencyConverter {
	public double dollarsToRupees(double dollars);
}
