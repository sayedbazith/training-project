package spring5;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;



public class Client
{
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		ApplicationContext factory=new AnnotationConfigApplicationContext(MyBookConfig.class);
		Book bookBean=(Book) factory.getBean("book");
		System.out.println(bookBean);
		System.out.println(bookBean.hashCode());
		
	}
}
