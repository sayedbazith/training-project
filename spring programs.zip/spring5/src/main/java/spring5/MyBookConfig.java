package spring5;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class MyBookConfig 
{
	@Bean(initMethod="setUp",destroyMethod="cleanUp")
	public Book book()
	{	
		Book bookName=new Book();
		bookName.setIsbn("data structure");
		bookName.setYear("2009");
		bookName.setAuthor(author());
		return bookName;
	}
	
	@Bean
	public Author author()
	{
		return new Author("remaThereja","hyderabad");
	}
}
