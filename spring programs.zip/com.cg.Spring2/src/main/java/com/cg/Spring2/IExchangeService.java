package com.cg.Spring2;

public interface IExchangeService {
	public double getExchangeRate();
}
