package com.cg.Spring2;

public class CurrencyConverterImp implements ICurrencyConverter {

	private IExchangeService  exchangeService; 
	
	
	public IExchangeService getExchangeService() {
		System.out.println("getExchangeService()");
		return exchangeService;
	}
	
	public void setExchangeService(IExchangeService exchangeService) {
		System.out.println("setExchangeService()");
		this.exchangeService = exchangeService;
	}
	
	public double dollarsToRupees(double dollars) {
		// TODO Auto-generated method stub
		System.out.println("dollarsToRupees()");
		return dollars*exchangeService.getExchangeRate();
	}

	public CurrencyConverterImp(IExchangeService exchangeService) {
		System.out.println("CurrencyConverterImp()");
	}
	
	

}
