package com.cg.Spring2;

public interface ICurrencyConverter {
	public double dollarsToRupees(double dollars);
}
