package labproblem1.employee;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext factory=new ClassPathXmlApplicationContext("employee.xml");
		Employee employee=(Employee) factory.getBean("employeeBean");
		System.out.println("Employee Details");
		System.out.println("------------------------------------------------------");
		System.out.println("Employee Id: "+employee.getEmployeeId());
		System.out.println("Employee Name: "+employee.getEmployeeName());
		System.out.println("Employee Age: "+employee.getEmployeeAge());
		System.out.println("Employee Bussiness Unit: "+employee.getBussinessUnit());
		System.out.println("Employee Salary: "+employee.getEmployeeSalary());
	}
}
