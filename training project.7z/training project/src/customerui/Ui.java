package customerui;

import java.util.Scanner;

import customerbean.CusBean;
import customerservice.CusService;
import customerservice.CusServiceImp;

public class Ui 
{
	static int idvalue=101;
	public static void main(String[] args) 
	{
		// TODO Auto-generated method stub
		CusService cservice=new CusServiceImp();
		Scanner scan=new Scanner(System.in);
		int id=0;
		boolean valid=false;
		double balance=0;
		while(true)
		{
			System.out.println(" ");
			System.out.println("Welcome To The Bank");
			System.out.println("1)Account Creation");
			System.out.println("2)Show Balance");
			System.out.println("3)Deposit");
			System.out.println("4)Withdraw");
			System.out.println("5)Fund Transfer");
			System.out.println("6)Print Transcations");
			System.out.println("7)Exit");
			int choice=scan.nextInt();
			switch (choice) 
			{
				case 1:
					System.out.println("enter the details  Name > 4,age > 18 ");
					String cusname=scan.next();
					int cusage=scan.nextInt();
					CusBean cus=new CusBean();
					cus.setCusname(cusname);
					cus.setCusage(cusage);
					cus.setCusid(idvalue);
					cus.setBalance(balance);
					valid=cservice.validate(cus);
					if(valid)
					{
						cservice.createAccount(cus);
						System.out.println(cus);
						idvalue++;
					}
					else
						System.err.println("details not according to conditions");
					break;
				case 2:
					System.out.println("enter the accnum id");
					id=scan.nextInt();
					cus=cservice.showBalance(id);
					if(cus!=null)
						System.out.println(cus);
					else
						System.err.println("not found");
					break;
				case 3:
						System.out.println("enter the id and amount to depsoit");
						id=scan.nextInt();
						balance=scan.nextDouble();
						cus=cservice.Deposit(id, balance);
						if(cus!=null)
							System.out.println("Done Deposit "+cus);
						else
							System.err.println("record not found");
					break;
				case 4:
						System.out.println("enter the id and amount to withdrawl");
						id=scan.nextInt();
						balance=scan.nextDouble();
						cus=cservice.withDraw(id, balance);
						if(cus!=null)
							System.out.println("Done withdrawl "+cus);
						else
							System.err.println("record not found");
						break;
				case 5:
						System.out.println("enter the id and amount");
						id=scan.nextInt();
						balance=scan.nextDouble();
						valid=cservice.fundTransfer(id, balance);
						if(valid)	
							System.out.println("success");
						else
							System.err.println("no record found");
						break;
				case 6:
						System.out.println("enter the id to get details");
						id=scan.nextInt();
						cservice.printTranscations(id);
						break;
				case 7:
						System.out.println("exited successfully");
						System.exit(0);
						break;
			}
		}
	
	}
	
}
