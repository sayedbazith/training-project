package customerservice;

import java.util.ArrayList;
import java.util.List;

import customerbean.CusBean;
import customerdao.CusDao;
import customerdao.CusDaoImp;

public class CusServiceImp implements CusService 
{
	CusDao cdao=new CusDaoImp();
	List<CusBean> a=new ArrayList<CusBean>();
	
	@Override
	public boolean validate(CusBean c) 
	{
		// TODO Auto-generated method stub
		boolean valid=false;
		if((c.getCusname().length())>=4)
		{
			if(c.getCusage()>18)
			{
				a.add(c);
				valid=true;
			}
		}
		return valid;
	}

	@Override
	public CusBean createAccount(CusBean c) 
	{
		// TODO Auto-generated method stub
		return cdao.createAccount(c);
	}

	@Override
	public CusBean showBalance(int id) 
	{
		// TODO Auto-generated method stub
		return cdao.showBalance(id);
	}

	@Override
	public CusBean Deposit(int id, double amount) 
	{
		// TODO Auto-generated method stub
		return cdao.Deposit(id, amount);
	}

	@Override
	public CusBean withDraw(int id, double amount)
	{
		// TODO Auto-generated method stub
		return cdao.withDraw(id, amount);
	}

	@Override
	public boolean fundTransfer(int id, double amount) 
	{
		// TODO Auto-generated method stub
		return cdao.fundTransfer(id, amount);
	}

	@Override
	public String printTranscations(int id) 
	{
		// TODO Auto-generated method stub
		System.out.println("id in sevice "+id);
		System.out.println("service imp " +cdao.printTranscations(id));
		return cdao.printTranscations(id);
	}

	
	
}
