package customerbean;

public class CusBean 
{
	private String cusname;
	private int cusage;
	private int cusid;
	private double balance;
	private double deposit;
	private double withdrawl;
	private String transcation;
	
	public double getDeposit() 
	{
		return deposit;
	}
	public void setDeposit(double deposit)
	{
		this.deposit = deposit;
	}
	public double getWithdrawl() {
		return withdrawl;
	}
	public void setWithdrawl(double withdrawl) 
	{
		this.withdrawl = withdrawl;
	}
	public String getTranscation()
	{
		return transcation;
	}
	public void setTranscation(String transcation) 
	{
		this.transcation = transcation;
	}
	public double getBalance()
	{
		return balance;
	}
	public void setBalance(double balance) 
	{
		this.balance = balance;
	}
	
	public String getCusname()
	{
		return cusname;
	}
	public void setCusname(String cusname) 
	{
		this.cusname = cusname;
	}
	public int getCusage() 
	{
		return cusage;
	}
	public void setCusage(int cusage) 
	{
		this.cusage = cusage;
	}
	public int getCusid()
	{
		return cusid;
	}
	public void setCusid(int cusid) 
	{
		this.cusid = cusid;
	}
	
	@Override
	public String toString() 
	{
		return "cusname=" + cusname + ", cusage=" + cusage
				+ ", cusid=" + cusid + ", balance=" + balance ;
	}
}
