package customerdao;



import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import customerbean.CusBean;

public class CusDaoImp implements CusDao 
{
	double bal;
	boolean valid=false;
	int value;
	String str=null;
	List<CusBean> list=new ArrayList<CusBean>();
	static Map<Integer,CusBean> trans=new HashMap<Integer,CusBean>();
	CusBean b=null;
	@Override
	public CusBean createAccount(CusBean c)
	{
		// TODO Auto-generated method stub
		list.add(c);
		return c;
	}

	@Override
	public CusBean showBalance(int id) 
	{
		// TODO Auto-generated method stub
	
			for (CusBean cusBean : list) 
			{
				if(id==cusBean.getCusid())
				{
					b=cusBean;
					break;
				}
				else
					b=null;
			}
		return b;
	}

	@Override
	public CusBean Deposit(int id, double amount) 
	{
		// TODO Auto-generated method stub
		
		for (CusBean cusBean : list) 
		{
			if(id==cusBean.getCusid())
			{
				bal=cusBean.getBalance()+amount;
				cusBean.setBalance(bal);
				b=cusBean;
				trans.put(id,b);
				break;
			}
			else
				b=null;
		}
		
		return b;
	}

	@Override
	public CusBean withDraw(int id, double amount) 
	{
		// TODO Auto-generated method stub
		
		for (CusBean cusBean : list) 
		{
			if(id==cusBean.getCusid())
			{
				bal=cusBean.getBalance()-amount;
				if(bal>=0)
				{	
					cusBean.setBalance(bal);
					b=cusBean;
					System.out.println("withdrawl success");
					trans.put(id,b);
					break;
				}
				else
				{
					System.out.println("no funds");
					b=cusBean;
				}
				break;
			}
			else
				b=null;
		}
		return b;
	}

	@Override
	public boolean fundTransfer(int id, double amount) 
	{
		// TODO Auto-generated method stub
		
		for (CusBean cusBean : list) 
		{
			if(id==cusBean.getCusid())
			{
				if(amount>0)
				{
					double balance=amount+cusBean.getBalance();
					cusBean.setBalance(balance);
					System.out.println(cusBean);
					valid=true;
				}
			}
			else
				valid=false;
		}		
		return valid;
	}
	@Override
	public String printTranscations(int id) 
	{
		// TODO Auto-generated method stub
		b=trans.get(id);
		System.out.println("print transc in cusdoaimp "+trans.get(id));
		return b.getTranscation();
	}
}
