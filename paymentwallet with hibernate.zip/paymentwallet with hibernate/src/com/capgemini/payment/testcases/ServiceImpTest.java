package com.capgemini.payment.testcases;

import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.List;

import org.junit.Test;

import com.capgemini.payment.bean.CustomerBean;
import com.capgemini.payment.bean.TranscationBean;
import com.capgemini.payment.exception.PaymentException;
import com.capgemini.payment.service.IService;
import com.capgemini.payment.service.ServiceImp;

public class ServiceImpTest {
	
	IService service=new ServiceImp();
	
	@Test
	public void testValidateCreateAccount() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(2500);
		bean.setCustomerName("rafi");
		boolean result=service.validate(bean);
		assertTrue(result);
	}
	
	@Test(expected=PaymentException.class)
	public void testValidateNameNull() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(2500);
		bean.setCustomerName(null);
		service.validate(bean);
	}
	
	@Test(expected=PaymentException.class)
	public void testValidateAgeNull() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(1);
		bean.setCustomerBalance(2500);
		bean.setCustomerName(null);
		service.validate(bean);
	}
	
	@Test(expected=PaymentException.class)
	public void testValidateBalanceNegetive() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(-2500);
		bean.setCustomerName("rafi");
		service.validate(bean);
	}
	
	@Test(expected=PaymentException.class)
	public void testValidateNumberNegetive() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("888638");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(2500);
		bean.setCustomerName("rafi");
		service.validate(bean);
	}
	
	/*@Test
	public void testCreateAccount() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("9542724356");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(2500);
		bean.setCustomerName("rafi");
		boolean result=service.createAccount(bean);
		assertTrue(result);
	}*/

	@Test(expected=PaymentException.class)
	public void testCreateAccountNegetive() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(2500);
		bean.setCustomerName(null);
		service.createAccount(bean);
	}	
	
	@Test
	public void testShowBalance() throws PaymentException {
		CustomerBean result=null;
		result=service.showBalance("8886385544");
		assertNull(result);
	}
	

	@Test
	public void testPrintTranscations() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		List<TranscationBean> list=null;
		list=service.printTranscations("9951289768");
		assertNull(list);
		
	}

	@Test
	public void testDeposit() {
		
	}

	@Test
	public void testWithDraw() {
		
	}

	@Test
	public void testFundTransfer() {
		
	}

}
