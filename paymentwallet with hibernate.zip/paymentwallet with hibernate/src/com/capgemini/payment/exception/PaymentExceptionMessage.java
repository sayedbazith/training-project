package com.capgemini.payment.exception;

public class PaymentExceptionMessage {
	//message
	public static final String ERROR1="Account not created";
	public static final String ERROR2="Name should not be Null";
	public static final String ERROR3="Name should greater than 3 characters";
	public static final String ERROR4="Name should be in alphabets only";
	public static final String ERROR5="Age should greater than 9 and less than 120";
	public static final String ERROR6="Amount sholud be greater than 0";
	public static final String ERROR7="Account number should length 10";
	public static final String ERROR8="Account number should start with 6-9";
	public static final String ERROR9="Account number should not be null";
	public static final String ERROR10="check the details";
	public static final String ERROR11="amount should be 0 to 10000 only";
}
