package com.capgemini.payment.bean;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
@Entity
public class CustomerBean {
	
	@Id
	private String accountNumber;
	@Column
	private String customerName;
	@Column
	private int customerAge;
	
	@Column
	private double customerBalance;
	
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public int getCustomerAge() {
		return customerAge;
	}
	public void setCustomerAge(int customerAge) {
		this.customerAge = customerAge;
	}
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getCustomerBalance() {
		return customerBalance;
	}
	public void setCustomerBalance(double customerBalance) {
		this.customerBalance = customerBalance;
	}
	
	
	@Override
	public String toString() {
		return "CustomerBean [customerName=" + customerName + ", customerAge=" + customerAge + ", accountNumber="
				+ accountNumber + ", customerBalance=" + customerBalance;
	}
	
}
