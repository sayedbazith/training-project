package com.capgemini.payment.database;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class DatabaseConnection {
	public static EntityManager createConnection()
	{
		EntityManagerFactory emf=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=emf.createEntityManager();
		return em;
	}
	public static void closeConnection(EntityManager em)
	{
		em.close();
	}
}
