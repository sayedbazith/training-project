package com.capgemini.payment.bean;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
public class TranscationBean {
	
	@Id
	@GeneratedValue
	private int id;
	@Column
	private String accountNumber;
	@Column
	private double deposit;
	@Column
	private double withdrawl;
	@Column
	private String transcationType;
	@Temporal(TemporalType.DATE)
	private Date transcationTime;
	
	
	public String getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(String accountNumber) {
		this.accountNumber = accountNumber;
	}
	public double getDeposit() {
		return deposit;
	}
	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}
	public double getWithdrawl() {
		return withdrawl;
	}
	public void setWithdrawl(double withdrawl) {
		this.withdrawl = withdrawl;
	}
	public String getTranscationType() {
		return transcationType;
	}
	public void setTranscationType(String transcationType) {
		this.transcationType = transcationType;
	}
	public Date getTranscationTime() {
		return transcationTime;
	}
	public void setTranscationTime(Date transcationTime) {
		this.transcationTime = transcationTime;
	}
	
	@Override
	public String toString() {
		return "accountNumber=" + accountNumber + ", deposit=" + deposit + ", withdrawl=" + withdrawl
				+ ", transcationType=" + transcationType + ", transcationTime=" + transcationTime;
	}
	
	
	
}
