package com.capgemini.payment.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;

import com.capgemini.payment.bean.CustomerBean;
import com.capgemini.payment.bean.TranscationBean;
import com.capgemini.payment.database.DatabaseConnection;
import com.capgemini.payment.exception.PaymentException;

public class DAOImp implements IDAO {

	@Override
	public boolean createAccount(CustomerBean c) {
		// TODO Auto-generated method stub
		EntityManager em=DatabaseConnection.createConnection();
		em.getTransaction().begin();
		boolean isValid = false;
		em.persist(c);
		TranscationBean transcationBean=new TranscationBean();
		transcationBean.setDeposit(c.getCustomerBalance());
		transcationBean.setTranscationType("account creation");
		transcationBean.setWithdrawl(0);
		transcationBean.setTranscationTime(new Date());
		transcationBean.setAccountNumber(c.getAccountNumber());
		em.persist(transcationBean);
		em.getTransaction().commit();
		isValid=true;
		DatabaseConnection.closeConnection(em);
		return isValid;
	}

	@Override
	public CustomerBean showBalance(String phoneNumber) throws PaymentException {
		// TODO Auto-generated method stub
		EntityManager em=DatabaseConnection.createConnection();
		CustomerBean bean = null;
		Query query=em.createQuery("from CustomerBean");
		List<CustomerBean> list=query.getResultList();
		for (CustomerBean customerBean : list) {
			if(customerBean.getAccountNumber().equals(phoneNumber))
				bean=customerBean;
		}
		DatabaseConnection.closeConnection(em);
		return bean;
	}

	@Override
	public boolean deposit(String phoneNumber, double amount) throws PaymentException {
		// TODO Auto-generated method stub
		EntityManager em=DatabaseConnection.createConnection();
		em.getTransaction().begin();
		boolean isValid = false;
		Query query=em.createQuery("from CustomerBean");
		List<CustomerBean> list=query.getResultList();
		TranscationBean transcationBean = new TranscationBean();
		if (amount > 0) {
			for (CustomerBean customerBean : list) {
				if (customerBean.getAccountNumber().equals(phoneNumber)) {
					double balance = customerBean.getCustomerBalance() + amount;
					customerBean.setCustomerBalance(balance);
					em.merge(customerBean);
					transcationBean.setAccountNumber(customerBean.getAccountNumber());
					transcationBean.setDeposit(amount);
					transcationBean.setTranscationTime(new Date());
					transcationBean.setTranscationType("deposit");
					transcationBean.setWithdrawl(0);
					em.persist(transcationBean);
					isValid = true;
					break;
				}
			}
		}
		else
			isValid=false;
		em.getTransaction().commit();
		DatabaseConnection.closeConnection(em);
		return isValid;
	}

	@Override
	public boolean withDraw(String phoneNumber, double amount) throws PaymentException {
		// TODO Auto-generated method stub
		EntityManager em=DatabaseConnection.createConnection();
		em.getTransaction().begin();
		boolean isValid = false;
		Query query=em.createQuery("from CustomerBean");
		List<CustomerBean> list=query.getResultList();
		TranscationBean transcationBean = new TranscationBean();
		if (amount > 0) 
		{
			for (CustomerBean customerBean : list)
			{
				if (customerBean.getAccountNumber().equals(phoneNumber))
				{
					double balance = customerBean.getCustomerBalance() - amount;
					if (balance >= 0)
					{
						customerBean.setCustomerBalance(balance);
						em.merge(customerBean);
						transcationBean.setAccountNumber(customerBean.getAccountNumber());
						transcationBean.setDeposit(0);
						transcationBean.setTranscationTime(new Date());
						transcationBean.setTranscationType("withdrawl");
						transcationBean.setWithdrawl(amount);
						em.persist(transcationBean);
						isValid = true;
						break;
					}
				}
			}
		}
		else
			isValid=false;
		em.getTransaction().commit();
		DatabaseConnection.closeConnection(em);
		return isValid;
	}

	@SuppressWarnings("unused")
	@Override
	public boolean fundTransfer(String sourcePhoneNumber, String targetPhoneNumber, double amount)
	 {
		// TODO Auto-generated method stub
		EntityManager em=DatabaseConnection.createConnection();
		em.getTransaction().begin();
		boolean isValid=false;
		Query query=em.createQuery("from CustomerBean");
		List<CustomerBean> list=query.getResultList();
		CustomerBean sourceCustomer=null;
		CustomerBean targetCustomer=null;
		TranscationBean sourceTranscation=new TranscationBean();
		TranscationBean targetTranscation=new TranscationBean();
		if(amount>0)
		{
			for (CustomerBean customerBean : list)
			{
				if(customerBean.getAccountNumber().equals(sourcePhoneNumber))
					sourceCustomer=customerBean;
				if(customerBean.getAccountNumber().equals(targetPhoneNumber))
					targetCustomer=customerBean;
			}
			if(sourceCustomer!=null)
			{
				double balance=sourceCustomer.getCustomerBalance()-amount;
				if(balance>=0)
				{
					sourceCustomer.setCustomerBalance(balance);
					if(targetCustomer!=null)
					{
						double transferAmount=targetCustomer.getCustomerBalance()+amount;
						targetCustomer.setCustomerBalance(transferAmount);
						em.merge(sourceCustomer);
						em.merge(targetCustomer);
						sourceTranscation.setAccountNumber(sourceCustomer.getAccountNumber());
						sourceTranscation.setDeposit(0);
						sourceTranscation.setTranscationTime(new Date());
						sourceTranscation.setTranscationType("fundtransfer");
						sourceTranscation.setWithdrawl(amount);
						em.persist(sourceTranscation);
						targetTranscation.setAccountNumber(targetCustomer.getAccountNumber());
						targetTranscation.setDeposit(amount);
						targetTranscation.setTranscationTime(new Date());
						targetTranscation.setTranscationType("fundtransfer");
						targetTranscation.setWithdrawl(0);
						em.persist(targetTranscation);
						isValid=true;
					}
					else
					{
						sourceCustomer.setCustomerBalance(sourceCustomer.getCustomerBalance()+amount);
						em.merge(sourceCustomer);
						isValid=false;
					}
				}
				else
					isValid=false;
			}
			else
				isValid=false;
		}
		em.getTransaction().commit();
		DatabaseConnection.closeConnection(em);
		return isValid;
	}

	@Override
	public List<TranscationBean> printTranscations(String phoneNumber) {
		// TODO Auto-generated method stub
		EntityManager em=DatabaseConnection.createConnection();
		List<TranscationBean> transcationList=new ArrayList<TranscationBean>();
		Query query=em.createQuery("from TranscationBean");
		List<TranscationBean> list=query.getResultList();
		for (TranscationBean transcationBean : list) {
			if(transcationBean.getAccountNumber().equals(phoneNumber))
				transcationList.add(transcationBean);
		}
		DatabaseConnection.closeConnection(em);
		return transcationList;
	}
}
