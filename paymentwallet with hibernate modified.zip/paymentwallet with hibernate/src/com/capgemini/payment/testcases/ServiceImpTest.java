package com.capgemini.payment.testcases;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNull;
import org.junit.Test;

import com.capgemini.payment.bean.CustomerBean;
import com.capgemini.payment.exception.PaymentException;
import com.capgemini.payment.service.IService;
import com.capgemini.payment.service.ServiceImp;

public class ServiceImpTest {
	
	IService service=new ServiceImp();
	
	/*@Test
	public void testValidateCreateAccount() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(2500);
		bean.setCustomerName("rafi");
		boolean result=service.validate(bean);
		assertTrue(result);
	}*/
	
	@Test(expected=PaymentException.class)
	public void testValidateNameNull() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(2500);
		bean.setCustomerName(null);
		service.validate(bean);
	}
	
	@Test(expected=PaymentException.class)
	public void testValidateAgeNull() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(1);
		bean.setCustomerBalance(2500);
		bean.setCustomerName(null);
		service.validate(bean);
	}
	
	@Test(expected=PaymentException.class)
	public void testValidateBalanceNegetive() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(-2500);
		bean.setCustomerName("rafi");
		service.validate(bean);
	}
	
	@Test(expected=PaymentException.class)
	public void testValidateNumberNegetive() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("888638");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(2500);
		bean.setCustomerName("rafi");
		service.validate(bean);
	}
	
	/*@Test //working
	public void testCreateAccount() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8686586905");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(2500);
		bean.setCustomerName("vamsi");
		boolean result=service.createAccount(bean);
		assertTrue(result);
	}*/

	@Test(expected=PaymentException.class)
	public void testCreateAccountNegetive() throws PaymentException {
		CustomerBean bean=new CustomerBean();
		bean.setAccountNumber("8886385538");
		bean.setCustomerAge(22);
		bean.setCustomerBalance(2500);
		bean.setCustomerName(null);
		service.createAccount(bean);
	}	
	
	@Test
	public void testShowBalance() throws PaymentException {
		CustomerBean result=null;
		result=service.showBalance("8886385544");
		assertNull(result);
	}

	/*@Test   //working
	public void testDeposit() throws PaymentException {
		boolean result=service.deposit("8886385538",200 );
		assertTrue(result);
	}*/
	
	@Test   
	public void testDepositNegetive() throws PaymentException {
		boolean result=service.deposit("8886385512",200 );
		assertFalse(result);
	}

	/*@Test //working
	public void testWithDraw() throws PaymentException {
		boolean result=service.withDraw("8686586905", 500);
		assertTrue(result);
	}*/

	@Test 
	public void testWithDrawNegetive() throws PaymentException {
		boolean result=service.withDraw("8886385512", 500);
		assertFalse(result);
	}
	
	/*@Test //working
	public void testFundTransfer() throws PaymentException {
		boolean result=service.fundTransfer("8886385538", "9492476179", 100);
		assertTrue(result);
	}*/

	@Test
	public void testFundTransferNegetive() throws PaymentException {
		boolean result=service.fundTransfer("8886385512", "9492476179", 100);
		assertFalse(result);
	}
}
