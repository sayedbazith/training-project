package com.cg.bankwallet.exception;

public class BankWalletExceptionMessage {
	public static final String ERROR1="please enter the valid Name";
	public static final String ERROR2="please enter the valid Age";
	public static final String ERROR3="please enter the valid PHONE NUMBER";
	public static final String ERROR4="details not according to conditions";
	public static final String ERROR5="Record NOT found";
	public static final String ERROR6="please enter the valid ADDRESS";
	public static final String ERROR7="balance not sufficent";
}
