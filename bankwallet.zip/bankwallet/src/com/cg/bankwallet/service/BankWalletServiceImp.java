package com.cg.bankwallet.service;

import com.cg.bankwallet.bean.BankWalletBean;
import com.cg.bankwallet.dao.BankWalletDaoImp;
import com.cg.bankwallet.dao.IBankWalletDao;
import com.cg.bankwallet.exception.BankWalletException;
import com.cg.bankwallet.exception.BankWalletExceptionMessage;

public class BankWalletServiceImp implements IBankWalletService {
	IBankWalletDao dao = new BankWalletDaoImp();

	@Override
	public boolean validate(BankWalletBean c) throws BankWalletException {
		// TODO Auto-generated method stub
		boolean valid = false;
		if (!((c.getFirstName().length()) >= 4)
				&& (c.getLastName().length() >= 3))
			throw new BankWalletException(BankWalletExceptionMessage.ERROR1);
		if (!(c.getAge() > 18))
			throw new BankWalletException(BankWalletExceptionMessage.ERROR2);
		if (!(c.getPhoneNumber().matches("^[7-9][0-9]{9}$")))
			throw new BankWalletException(BankWalletExceptionMessage.ERROR3);
		if (!(((c.getPan().length() == 10)) && (c.getPan() != null)))
			throw new BankWalletException(BankWalletExceptionMessage.ERROR3);
		if (!(c.getAddress().length() >= 4))
			throw new BankWalletException(BankWalletExceptionMessage.ERROR6);
		valid = true;
		return valid;
	}

	@Override
	public BankWalletBean createAccount(BankWalletBean c) {
		// TODO Auto-generated method stub
		return dao.createAccount(c);
	}

	@Override
	public BankWalletBean showBalance(String accountNumber) {
		// TODO Auto-generated method stub
		return dao.showBalance(accountNumber);
	}

	@Override
	public BankWalletBean deposit(String accountNumber, double amount) {
		// TODO Auto-generated method stub
		return dao.deposit(accountNumber, amount);
	}

	@Override
	public BankWalletBean withDraw(String accountNumber, double amount) {
		// TODO Auto-generated method stub
		return dao.withDraw(accountNumber, amount);
	}

	@Override
	public BankWalletBean fundTransfer(String accountNumberSource,
			String accountNumberTarget, double amount) {
		// TODO Auto-generated method stub
		return dao.fundTransfer(accountNumberSource, accountNumberTarget,
				amount);
	}

	@Override
	public String printTranscations(String accountNumber) {
		// TODO Auto-generated method stub
		return dao.printTranscations(accountNumber);
	}

}
