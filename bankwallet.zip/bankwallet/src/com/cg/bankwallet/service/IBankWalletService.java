package com.cg.bankwallet.service;

import com.cg.bankwallet.bean.BankWalletBean;
import com.cg.bankwallet.exception.BankWalletException;


public interface IBankWalletService
{
	public boolean validate(BankWalletBean c) throws BankWalletException;
	public BankWalletBean createAccount(BankWalletBean c);
	public BankWalletBean showBalance(String accountNumber);
	public BankWalletBean deposit(String accountNumber,double amount);
	public BankWalletBean withDraw(String accountNumber,double amount);
	public BankWalletBean fundTransfer(String accountNumbergSource,String accountNumberTarget,double amount);
	public String printTranscations(String accountNumber);
}
