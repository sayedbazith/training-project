package com.cg.bankwallet.ui;
import java.util.Scanner;
import com.cg.bankwallet.bean.BankWalletBean;
import com.cg.bankwallet.exception.BankWalletException;
import com.cg.bankwallet.exception.BankWalletExceptionMessage;
import com.cg.bankwallet.service.BankWalletServiceImp;
import com.cg.bankwallet.service.IBankWalletService;

public class BankWalletUi {
	public static void main(String[] args) throws BankWalletException {
		// TODO Auto-generated method stub
		IBankWalletService service = new BankWalletServiceImp();
		Scanner scan = new Scanner(System.in);
		String account;
		boolean valid = false;
		double balance = 0;
		while (true) {
			System.out.println(" ");
			System.out.println("Welcome To The Bank");
			System.out.println("1)Account Creation");
			System.out.println("2)Show Balance");
			System.out.println("3)Deposit");
			System.out.println("4)Withdraw");
			System.out.println("5)Fund Transfer");
			System.out.println("6)Print Transcations");
			System.out.println("7)Exit");
			int choice = scan.nextInt();
			BankWalletBean bean = new BankWalletBean();
			switch (choice) {
			case 1:
				try {
					System.out.println("enter the details  Name > 4,age > 18 ,phone,pan");
					String firstName = scan.next();
					String lastName = scan.next();
					int customerage = scan.nextInt();
					String phoneNumber = scan.next();
					String pan = scan.next();
					bean.setFirstName(firstName);
					bean.setLastName(lastName);
					bean.setAge(customerage);
					bean.setPhoneNumber(phoneNumber);
					bean.setPan(pan);
					valid = service.validate(bean);
					if (valid)
						service.createAccount(bean);
					else
						throw new BankWalletException(BankWalletExceptionMessage.ERROR4);
				} catch (Exception ex) {
					System.out.println(ex);
				}
				break;
			case 2:
				try {
					System.out.println("enter the phonenumber ");
					account = scan.next();
					bean = service.showBalance(account);
					if (bean != null)
						System.out.println(bean);
					else
						throw new BankWalletException(BankWalletExceptionMessage.ERROR5);
				} catch (Exception ex) {
					System.out.println(ex);
				}
				break;
			case 3:
				try {
					System.out.println("enter the phonenumber and amount to depsoit");
					account = scan.next();
					balance = scan.nextDouble();
					bean = service.deposit(account, balance);
					if (bean != null)
						System.out.println("Done Deposit " + bean.toStr());
					else
						throw new BankWalletException(BankWalletExceptionMessage.ERROR5);
				} catch (Exception ex) {
					System.out.println(ex);
				}
				break;
			case 4:
				try {
					System.out.println("enter the phonenumber and amount to withdrawl");
					account = scan.next();
					balance = scan.nextDouble();
					bean = service.withDraw(account, balance);
					if (bean != null)
						System.out.println(bean.toStr());
					else
						throw new BankWalletException(BankWalletExceptionMessage.ERROR5);
				} catch (Exception ex) {
					System.out.println(ex);
				}
				break;
			case 5:
				try {
					System.out.println("enter the phonenumbersource,phonenumbertarget and amount");
					String numberSource = scan.next();
					String numberTarget = scan.next();
					balance = scan.nextDouble();
					bean = service.fundTransfer(numberSource, numberTarget, balance);
					if (bean != null)
						System.out.println(bean.toStr());
					else
						throw new BankWalletException(BankWalletExceptionMessage.ERROR5);
				} catch (Exception ex) {
					System.out.println(ex);
				}
				break;
			case 6:
				try {
					System.out.println("enter the id to get details");
					account = scan.next();
					service.printTranscations(account);
				} catch (Exception ex) {
					System.out.println(ex);
				}
				break;
			case 7:
				System.out.println("exited successfully");
				System.exit(0);
				break;
			}
		}
	}

}
