package com.cg.bankwallet.dao;

import com.cg.bankwallet.bean.BankWalletBean;

public interface IBankWalletDao 
{
	
	public BankWalletBean createAccount(BankWalletBean c);
	public BankWalletBean showBalance(String accountNumber);
	public BankWalletBean deposit(String accountNumber,double amount);
	public BankWalletBean withDraw(String accountNumber,double amount);
	public BankWalletBean fundTransfer(String accountNumbergSource,String accountNumberTarget,double amount);
	public String printTranscations(String accountNumber);
}
