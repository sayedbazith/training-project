package com.cg.bankwallet.dao;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import com.cg.bankwallet.bean.BankWalletBean;
import com.cg.bankwallet.exception.BankWalletException;
import com.cg.bankwallet.exception.BankWalletExceptionMessage;

public class BankWalletDaoImp implements IBankWalletDao {
	List<BankWalletBean> bankDetails = new ArrayList<BankWalletBean>();
	List<BankWalletBean> trans = new ArrayList<BankWalletBean>();
	double bal;
	boolean isValid = false;
	String str = null;
	BankWalletBean b;

	@Override
	public BankWalletBean createAccount(BankWalletBean bean) {

		bean.setTime(LocalTime.now().toString());
		bean.setDeposit(0);
		bean.setWithdrawl(0);
		bean.setTranscationType("creation account");
		bankDetails.add(bean);
		System.out.println(bean);
		return bean;
	}

	@Override
	public BankWalletBean showBalance(String accountNumber) {
		// TODO Auto-generated method stub
		int number = Integer.parseInt(accountNumber);
		for (BankWalletBean bean : bankDetails) {
			int phoneCheck = Integer.parseInt(bean.getPhoneNumber());
			if (number == phoneCheck) {
				b = bean;
			}
		}
		return b;
	}

	@Override
	public BankWalletBean deposit(String accountNumber, double amount) {
		int number = Integer.parseInt(accountNumber);
		for (BankWalletBean bean : bankDetails) {
			int phoneCheck = Integer.parseInt(bean.getPhoneNumber());
			if (number == phoneCheck) {
				if (bal >= 0) {
					bean.setBalance(bean.getBalance() + amount);
					BankWalletBean be = new BankWalletBean();
					be.setPhoneNumber(accountNumber);
					be.setBalance(bean.getBalance());
					be.setTime(LocalTime.now().toString());
					be.setDeposit(amount);
					be.setWithdrawl(0);
					be.setTranscationType("deposit");
					trans.add(be);
					b = be;
				}
			}
		}
		return b;
	}

	@Override
	public BankWalletBean withDraw(String accountNumber, double amount) {
		int number = Integer.parseInt(accountNumber);
		for (BankWalletBean bean : bankDetails) {
			int phoneCheck = Integer.parseInt(bean.getPhoneNumber());
			if (number == phoneCheck) {
				bal = bean.getBalance() - amount;
				bankDetails.add(bean);
				if (bal >= 0) {
					bean.setBalance(bean.getBalance() - amount);
					BankWalletBean be = new BankWalletBean();
					be.setPhoneNumber(accountNumber);
					be.setBalance(bean.getBalance());
					be.setTime(LocalTime.now().toString());
					be.setDeposit(0);
					be.setWithdrawl(amount);
					be.setTranscationType("withdrawl");
					trans.add(be);
					b = be;
				} else {
					System.out.println("no funds");
				}
			}

		}
		return b;
	}

	@Override
	public BankWalletBean fundTransfer(String accountNumberSource,
			String accountNumberTarget, double amount) {
		try
		{
		BankWalletBean src = null;
		BankWalletBean dest = null;
		int numberSource = Integer.parseInt(accountNumberSource);
		int numberTarget = Integer.parseInt(accountNumberTarget);
		for (BankWalletBean bean : bankDetails) {
			int phoneCheck = Integer.parseInt(bean.getPhoneNumber());
			if (numberSource == phoneCheck)
				src = bean;
			if (numberTarget == phoneCheck)
				dest = bean;
		}

		if (src == null) {
			throw new BankWalletException(BankWalletExceptionMessage.ERROR5);
		} else {
			if (src.getBalance() - amount > 0) {
				src.setBalance(src.getBalance() - amount);
				BankWalletBean be = new BankWalletBean();
				be.setBalance(src.getBalance());
				be.setPhoneNumber(src.getPhoneNumber());
				be.setTime(LocalTime.now().toString());
				be.setWithdrawl(amount);
				be.setDeposit(0);
				be.setTranscationType("fund transfer");
				bankDetails.add(be);
			} else
				throw new BankWalletException(BankWalletExceptionMessage.ERROR5);
			if (dest == null) {
				src.setBalance(src.getBalance() + amount);
				BankWalletBean be = new BankWalletBean();
				be.setPhoneNumber(src.getPhoneNumber());
				be.setBalance(src.getBalance());
				be.setTime(LocalTime.now().toString());
				be.setWithdrawl(0);
				be.setDeposit(amount);
				be.setTranscationType("fund transfer");
				bankDetails.add(be);
				return null;
			}
			BankWalletBean be = new BankWalletBean();
			be.setPhoneNumber(accountNumberTarget);
			be.setPhoneNumber(dest.getPhoneNumber());
			be.setBalance(dest.getBalance() + amount);
			be.setTime(LocalTime.now().toString());
			be.setDeposit(amount);
			be.setWithdrawl(0);
			be.setTranscationType("fund transfer");
			trans.add(be);
			return be;
		}
	}
	catch(Exception ex)
	{
		System.out.println(ex);
	}
		return null;
	}

	@Override
	public String printTranscations(String accountNumber) {
		// TODO Auto-generated method stub
		int number = Integer.parseInt(accountNumber);
		for (BankWalletBean bankWalletBean : trans) {
			int phoneCheck = Integer.parseInt(bankWalletBean.getPhoneNumber());
			if (phoneCheck == number) {
				System.out.println(bankWalletBean);
			}
		}
		return null;
	}

}
