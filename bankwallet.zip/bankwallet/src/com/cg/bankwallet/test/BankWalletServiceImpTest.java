package com.cg.bankwallet.test;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.bankwallet.bean.BankWalletBean;
import com.cg.bankwallet.exception.BankWalletException;
import com.cg.bankwallet.service.BankWalletServiceImp;
import com.cg.bankwallet.service.IBankWalletService;

public class BankWalletServiceImpTest {
	static IBankWalletService service;
	static BankWalletBean beanObj;
	boolean result;
	@BeforeClass
	public static void createInstance() 
	{
		service=new BankWalletServiceImp();
	}
	
	@Test
	public void testCreateAccount()throws BankWalletException{
		BankWalletBean bean=new BankWalletBean();
		bean.setFirstName("raju");
		bean.setLastName("krishna");
		bean.setPhoneNumber("8886385538");
		bean.setAddress("novotel");
		bean.setAge(22);
		bean.setPan("qwertyuiop");
		result=service.validate(bean);
		Assert.assertTrue(result);
	}
	@Test(expected=NullPointerException.class)
	public void testCreateAccountNotNull()throws BankWalletException{
		BankWalletBean bean=new BankWalletBean();
		bean.setFirstName(null);
		bean.setLastName("krishna");
		bean.setPhoneNumber("8886385538");
		bean.setAddress("novotel");
		bean.setAge(22);
		bean.setPan("qwertyuiop");
		result=service.validate(bean);
		Assert.assertFalse(result);
	}
}
