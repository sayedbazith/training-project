package com.capg.paytm.exception;

public class ExceptionMessage {
	public static final String ERROR1 = "invalid phone no";
	public static final String ERROR2 = "phone number should contain only numbers";
	public static final String ERROR4 = "4amount should be a positive value";


}
