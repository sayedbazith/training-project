package com.capg.paytm.exception;

public class PaytmException extends Exception {
	public PaytmException() {
		super();

	}

	public PaytmException(String message) {
		super(message);

	}

}
