package com.capg.paytm.bean;

public class PaytmBean {
	private double deposit;

	private double balance;
	private String phnNo;

	public double getDeposit() {
		return deposit;
	}

	public String getPhnNo() {
		return phnNo;
	}

	public void setPhnNo(String phnNo) {
		this.phnNo = phnNo;
	}

	public void setDeposit(double deposit) {
		this.deposit = deposit;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

}
