package com.capg.paytm.service;

import com.capg.paytm.bean.PaytmBean;
import com.capg.paytm.exception.PaytmException;

public interface IPaytmService {
	public boolean deposit(PaytmBean bean1) throws PaytmException ;
}
