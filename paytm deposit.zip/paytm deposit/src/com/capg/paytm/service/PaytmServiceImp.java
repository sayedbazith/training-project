package com.capg.paytm.service;

import com.capg.paytm.bean.PaytmBean;
import com.capg.paytm.dao.IPaytmDao;
import com.capg.paytm.dao.PaytmDaoImp;



public class PaytmServiceImp implements IPaytmService {
	IPaytmDao dao = new PaytmDaoImp();

	public boolean deposit(PaytmBean bean1) {

		return dao.deposit(bean1);
	}



}
