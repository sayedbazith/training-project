package com.capg.paytm.test;

import org.junit.Assert;
import org.junit.BeforeClass;
import com.capg.paytm.bean.PaytmBean;

import com.capg.paytm.exception.PaytmException;
import com.capg.paytm.service.IPaytmService;
import com.capg.paytm.service.PaytmServiceImp;


public class Test {
	private static IPaytmService service = null;

	@BeforeClass
	public static void createInstance() {
		service = new PaytmServiceImp();
	}
	
	
	
	@org.junit.Test
	public void testDepositedForWrongPhn() throws PaytmException {
		PaytmBean bean = new PaytmBean();
		bean.setPhnNo("9059900988");
		bean.setDeposit(2000);
		boolean result = service.deposit(bean);
		Assert.assertFalse(result);
	}
	@org.junit.Test
	public void testDepositForNegative() throws PaytmException {
		PaytmBean bean = new PaytmBean();
		bean.setPhnNo("9059900989");
		bean.setDeposit(-2000);
		boolean result = service.deposit(bean);
		Assert.assertFalse(result);
	}
	@org.junit.Test
	public void testDeposited() throws PaytmException {
		PaytmBean bean = new PaytmBean();
		bean.setPhnNo("9059900989");
		bean.setDeposit(2000);
		boolean result = service.deposit(bean);
		Assert.assertTrue(result);
	}
	
	@org.junit.Test
	public void testForPhnlength() throws PaytmException {
		PaytmBean bean = new PaytmBean();
		bean.setPhnNo("9059900");
		bean.setDeposit(2000);
		boolean result = service.deposit(bean);
		Assert.assertFalse(result);
	}
	@org.junit.Test
	public void testFornotnull() throws PaytmException {
		PaytmBean bean = new PaytmBean();
		bean.setPhnNo(null);
		bean.setDeposit(2000);
		boolean result = service.deposit(bean);
		Assert.assertFalse(result);
	}
	@org.junit.Test
	public void testForonlynumbers() throws PaytmException {
		PaytmBean bean = new PaytmBean();
		bean.setPhnNo("905ghd");
		bean.setDeposit(2000);
		boolean result = service.deposit(bean);
		Assert.assertFalse(result);
	
	}
	}
