package com.capg.paytm.dao;

import com.capg.paytm.bean.PaytmBean;

public interface IPaytmDao {
	public boolean deposit(PaytmBean bean1);

}
