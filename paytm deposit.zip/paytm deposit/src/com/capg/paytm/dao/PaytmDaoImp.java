package com.capg.paytm.dao;

import java.util.ArrayList;

import com.capg.paytm.bean.PaytmBean;
import com.capg.paytm.exception.ExceptionMessage;
import com.capg.paytm.exception.PaytmException;
import com.capg.paytm.service.IPaytmService;

public class PaytmDaoImp implements IPaytmDao {
	private static IPaytmService service = null;
	ArrayList<PaytmBean> depositList = new ArrayList<PaytmBean>();

	public void addAccount() {
		PaytmBean b1 = new PaytmBean();
		b1.setPhnNo("9059900989");
		b1.setBalance(5000);
		depositList.add(b1);
		PaytmBean b2 = new PaytmBean();
		b2.setPhnNo("9059900979");
		b2.setBalance(5000);
		depositList.add(b2);

	}

	public boolean deposit(PaytmBean bean1) {
		addAccount();

		boolean status = false;
		try {
			PaytmBean b1 = null;
			for (PaytmBean bean : depositList) {
				if (bean1.getPhnNo().equals(bean.getPhnNo())) {
					b1 = bean;
				}
			}

			if (bean1.getDeposit() <= 0) {

				throw new PaytmException(ExceptionMessage.ERROR4);
			} else {
				b1.setBalance(b1.getBalance() + bean1.getDeposit());
				status = true;
				System.out.println(b1.getBalance());
			}
		} catch (Exception exception1) {
			System.out.println(exception1.getMessage());
		}
		return status;
	}

	

}
