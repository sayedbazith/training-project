package com.capg.bankwallet.dao;

import java.util.ArrayList;

import com.capg.bankwallet.bean.BankWalletBean;
import com.capg.bankwallet.exception.BankWalletException;

public class BankWalletDaoImp implements IBankWalletDao {
ArrayList<BankWalletBean> list=new ArrayList<BankWalletBean>();
	@Override
	public boolean addCustomer(BankWalletBean bean) {
		// TODO Auto-generated method stub
		
		list.add(bean);
		System.out.println("account created successfully");
		System.out.println(list);
		return false;
	}

	@Override
	public boolean validate(BankWalletBean bean) throws BankWalletException {
		// TODO Auto-generated method stub
		return false;
	}

}
