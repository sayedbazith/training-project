package com.capg.bankwallet.dao;

import com.capg.bankwallet.bean.BankWalletBean;
import com.capg.bankwallet.exception.BankWalletException;

public interface IBankWalletDao {
	
	
	
	
	public boolean addCustomer(BankWalletBean bean);
	public boolean validate(BankWalletBean bean) throws BankWalletException;

}
