package com.capg.bankwallet.bean;

public class BankWalletBean {

	private String firstName;
	private String lastName;

	private String PanNo;
	private double balance;

	private String phnNo;
	private String alternatePhnNo;

	public String getPanNo() {
		return PanNo;
	}

	public void setPanNo(String panNo) {
		PanNo = panNo;
	}

	public String getAlternatePhnNo() {
		return alternatePhnNo;
	}

	

	public void setAlternatePhnNo(String alternatePhnNo) {
		this.alternatePhnNo = alternatePhnNo;
	}

	private String address;

	public String getPhnNo() {
		return phnNo;
	}

	public void setPhnNo(String phnNo) {
		this.phnNo = phnNo;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "BankWalletBean [firstName=" + firstName + ", lastName="
				+ lastName + ", PanNo=" + PanNo + ", balance=" + balance
				+ ", phnNo=" + phnNo + ", alternatePhnNo=" + alternatePhnNo
				+ ", address=" + address + "]";
	}

}
