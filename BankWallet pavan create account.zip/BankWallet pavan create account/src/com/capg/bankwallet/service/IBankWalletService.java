package com.capg.bankwallet.service;

import com.capg.bankwallet.bean.BankWalletBean;
import com.capg.bankwallet.exception.BankWalletException;

public interface IBankWalletService {
	
	public boolean addCustomer(BankWalletBean bean) throws BankWalletException;
	public boolean validate(BankWalletBean bean) throws BankWalletException;
	
	

}
