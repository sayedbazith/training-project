package com.capg.bankwallet.service;

import com.capg.bankwallet.bean.BankWalletBean;
import com.capg.bankwallet.dao.BankWalletDaoImp;
import com.capg.bankwallet.dao.IBankWalletDao;
import com.capg.bankwallet.exception.BankWalletException;
import com.capg.bankwallet.exception.BankWalletExceptionMessage;

public class BankWalletService implements IBankWalletService {


	
	IBankWalletDao dao=new BankWalletDaoImp();
	@Override
	public boolean addCustomer(BankWalletBean bean) throws BankWalletException  {
		// TODO Auto-generated method stub
		
		//dao.addCustomer(bean);
		
		return validate(bean);
	}

	@Override
	public boolean validate(BankWalletBean bean) throws BankWalletException {

		// TODO Auto-generated method stub

		boolean isValid = false;
		if (!(bean.getBalance() >500)) {

			throw new BankWalletException(BankWalletExceptionMessage.ERROR1);

		}
		 if (bean.getFirstName() == null && bean.getFirstName().length() < 4) {

			throw new BankWalletException(BankWalletExceptionMessage.ERROR2);

		}
		 if(!(bean.getFirstName().matches("[a-z A-Z]{4,}"))){
			throw new BankWalletException(BankWalletExceptionMessage.ERROR2);
		}
		
		if (bean.getLastName() == null|| !bean.getLastName().matches("[a-z A-Z]{4,}")) {
			throw new BankWalletException(BankWalletExceptionMessage.ERROR3);

		}
	
		
		
		 if (!(bean.getPhnNo().matches("^[7-9][0-9]{9}"))){
			throw new BankWalletException(BankWalletExceptionMessage.ERROR4);

		}
		 if (!(bean.getAlternatePhnNo().matches("^[7-9][0-9]{9}"))){
			throw new BankWalletException(BankWalletExceptionMessage.ERROR4);

		}

		if (bean.getAddress() == null) {
			throw new BankWalletException(BankWalletExceptionMessage.ERROR5);

		}
		if(bean.getPanNo()==null|| bean.getPanNo().length()!=10){
			throw new BankWalletException(BankWalletExceptionMessage.ERROR6);
			
		}

	
			isValid=true;
		

	
		return isValid;
		
	}

	
}
