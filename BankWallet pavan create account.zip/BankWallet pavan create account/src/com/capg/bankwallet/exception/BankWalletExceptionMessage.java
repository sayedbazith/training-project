package com.capg.bankwallet.exception;

public class BankWalletExceptionMessage extends Exception{

	public static final String ERROR1="please enter the valid BALANCE";
	public static final String ERROR2="please enter the valid FIRST NAME";
	public static final String ERROR3="please enter the valid LAST NAME";
	public static final String ERROR4="please enter the valid PHONE NUMBER";
	public static final String ERROR5="please enter the valid ADDRESS";
	public static final String ERROR6 = "please enter the valid PAN NUMBER";

}
