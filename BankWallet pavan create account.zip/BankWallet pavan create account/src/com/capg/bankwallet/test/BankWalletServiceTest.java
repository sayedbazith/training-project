package com.capg.bankwallet.test;

import static org.junit.Assert.assertTrue;

import org.junit.Assert;
import org.junit.BeforeClass;
import org.junit.Test;

import com.capg.bankwallet.bean.BankWalletBean;
import com.capg.bankwallet.exception.BankWalletException;
import com.capg.bankwallet.service.BankWalletService;
import com.capg.bankwallet.service.IBankWalletService;

public class BankWalletServiceTest {

	private static IBankWalletService service = null;
IBankWalletService service1=new BankWalletService();

	@BeforeClass
	public static void createInstance() {

		service = new BankWalletService();

	}

	@Test(expected = BankWalletException.class)
	public void testBalanceforMinimum() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("sain");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("8885860870");
		bean.setBalance(400);
		bean.setPanNo("CMHPA23456L");
		boolean result = service.addCustomer(bean);
		
		Assert.assertFalse(result);

	}
	@Test
	public void testBalanceforPositive() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("sain");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("8885860870");
		bean.setPanNo("CMHPA23456");
		bean.setBalance(600);
		boolean result = service.addCustomer(bean);

		Assert.assertTrue(result);

	}
	@Test
	public void testphnNoforPositive() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("nath");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setPanNo("CMHPA237kl");
		bean.setAlternatePhnNo("8885860870");
		bean.setBalance(600);
		boolean result = service.addCustomer(bean);
		assertTrue(result);

	}
	@Test(expected = NullPointerException.class)
	public void testphnNofornull() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("nath");
		bean.setAddress("hyderabad");
		bean.setPhnNo(null);
		bean.setPanNo("CMHPA2374L66");
		
		bean.setAlternatePhnNo("8885860870");
		bean.setBalance(600);
		boolean result = service.addCustomer(bean);
		Assert.assertFalse(result);

	}
	@Test(expected = BankWalletException.class)
	public void testphnNoforlength() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("nath");
		bean.setAddress("hyderabad");
		bean.setPhnNo("888586087011");
		bean.setAlternatePhnNo("8885860870");
		bean.setPanNo("CMHPA2374L56");
		bean.setBalance(600);
		boolean result = service.addCustomer(bean);
		Assert.assertFalse(result);

	}
	@Test(expected = BankWalletException.class)
	public void testphnNodontStartWithZero() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("nath");
		bean.setAddress("hyderabad");
		bean.setPhnNo("08885860870");
		bean.setAlternatePhnNo("8885860870");
		bean.setPanNo("CMHPA2374L12");
		bean.setBalance(600);
		boolean result = service.addCustomer(bean);
		Assert.assertFalse(result);

	}
	@Test(expected = BankWalletException.class)
	public void testphnNodontcontainSpecialCharct() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("nath");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885#860870");
		bean.setAlternatePhnNo("885860870");
		bean.setPanNo("CMHPA2374L56");
		bean.setBalance(600);
		boolean result = service.addCustomer(bean);
		Assert.assertFalse(result);

	}
	@Test
	public void testalternatephnNoforPositive() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("nath");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setPanNo("CMHPA2374l");
		bean.setAlternatePhnNo("8885860870");
		bean.setBalance(600);
		boolean result = service.addCustomer(bean);
		Assert.assertTrue(result);

	}
	@Test(expected = BankWalletException.class)
	public void testalternatephnNoforlength() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("nath");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("888586070");
		bean.setPanNo("CMHPA2374L");
		bean.setBalance(600);
		boolean result = service.addCustomer(bean);
		Assert.assertFalse(result);

	}
	@Test(expected = BankWalletException.class)
	public void alternatetestphnNodontStartWithZero() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("nath");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("0885860870");
		bean.setPanNo("CMHPA2374L6l");
		bean.setBalance(600);
		boolean result = service.addCustomer(bean);
		Assert.assertFalse(result);

	}
	@Test(expected = BankWalletException.class)
	public void alternatetestphnNodontcontainSpecialCharct() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("nath");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("888#5860870");
		bean.setPanNo("CMHPA2374L");
		bean.setBalance(600);
		boolean result = service.addCustomer(bean);
		Assert.assertFalse(result);

	}
	@Test(expected = BankWalletException.class)
	public void testfirstNamefornospecialCharcters() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pav&an");
		bean.setLastName("sain");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("8885860870");
		bean.setPanNo("CMHPA2374L67");
		bean.setBalance(600);
		
		boolean result = service.addCustomer(bean);
		Assert.assertFalse(result);

	}@Test(expected = NullPointerException.class)
	public void testfirstNamefornotNull() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName(null);
		bean.setLastName("sain");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("8885860870");
		bean.setPanNo("CMHPA2374L");
		bean.setBalance(600);
		
		boolean result = service.addCustomer(bean);
		Assert.assertFalse(result);

	}@Test
	public void testfirstNameforPositive() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("sain");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("8885860870");
		bean.setPanNo("CMHPA2374L");
		bean.setBalance(600);
		
		boolean result = service.addCustomer(bean);
		Assert.assertTrue(result);

	}
	@Test(expected = BankWalletException.class)
	public void testfirstNameforlength() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pav");
		bean.setLastName("sain");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("8885860870");
		bean.setPanNo("CMHPA2374L65");
		bean.setBalance(600);
		boolean result = service.addCustomer(bean);
		Assert.assertFalse(result);

	}
	@Test
	public void testAddressfornotnull() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("sain");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("8885860870");
		bean.setPanNo("CMHPA2374k");
		bean.setBalance(600);
		boolean result=service.addCustomer(bean);
		Assert.assertTrue(result);
		
		}
	
	@Test(expected = BankWalletException.class)
	public void testAddressfornull() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("sain");
		bean.setAddress(null);
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("8885860870");
		bean.setPanNo("CMHPA2374L6256");
		bean.setBalance(600);
		boolean result=service.addCustomer(bean);
		Assert.assertFalse(result);
		
		}
	@Test
	public void testPanNofornotNull() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("sain");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("8885860870");
		bean.setPanNo("cmhpa3333f");
		bean.setBalance(600);
		boolean result=service.addCustomer(bean);
		Assert.assertTrue(result);
		
		}
	@Test
	public void testPanNoforNull() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("sain");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("8885860870");
		bean.setPanNo("FASDC56475");
		bean.setBalance(600);
		boolean result=service.addCustomer(bean);
		Assert.assertTrue(result);
		
		}
	@Test(expected = BankWalletException.class)
	public void testLastNameforlength() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("sai");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("8885860870");
		bean.setPanNo("CMHPA2374L66");
		bean.setBalance(600);
		boolean result = service.addCustomer(bean);
		Assert.assertFalse(result);
		

	}
	@Test(expected = BankWalletException.class)
	public void testLastNamedontcontainSpecialcharcters() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("s&ai");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("8885860870");
		bean.setPanNo("CMHPA2374L66");
		bean.setBalance(600);
		boolean result = service.addCustomer(bean);
		Assert.assertFalse(result);
		

	}
	@Test(expected = BankWalletException.class)
	public void testLastNamedontbeEmpty() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName(null);
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("8885860870");
		bean.setPanNo("CMHPA2374L66");
		bean.setBalance(600);
		boolean result = service.addCustomer(bean);
		Assert.assertFalse(result);
		

	}
	@Test
	public void testLastNameforPositive() throws BankWalletException {

		BankWalletBean bean = new BankWalletBean();
		bean.setFirstName("pavan");
		bean.setLastName("sain");
		bean.setAddress("hyderabad");
		bean.setPhnNo("8885860870");
		bean.setAlternatePhnNo("8885860870");
		bean.setPanNo("CMHPA2374L");
		bean.setBalance(600);
	
		boolean result = service.addCustomer(bean);
		Assert.assertTrue(result);
		

	}
	

}
