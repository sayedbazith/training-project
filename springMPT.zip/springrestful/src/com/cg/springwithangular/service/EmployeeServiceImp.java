package com.cg.springwithangular.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.cg.springwithangular.beans.Employee;
import com.cg.springwithangular.dao.IEmployeeDAO;


@Service("empservice")
public class EmployeeServiceImp implements IEmployeeService {
	@Autowired
	IEmployeeDAO empDAO;
	@Override
	public List<Employee> getAllEmployee() {
		// TODO Auto-generated method stub
		return empDAO.getAllEmployee();
	}

	@Override
	public void addEmployee(Employee emp) {
		// TODO Auto-generated method stub
		empDAO.addEmployee(emp);
	}

	@Override
	public void deleteEmployee(int id) {
		// TODO Auto-generated method stub
		empDAO.deleteEmployee(id);
	}

	@Override
	public Employee searchEmployee(int id) {
		// TODO Auto-generated method stub
		return empDAO.searchEmployee(id);
	}

	@Override
	public void updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		empDAO.updateEmployee(emp);
	}
}
