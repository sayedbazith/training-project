package com.cg.springmvcone.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.cg.springmvcone.dao.IEmployeeDAO;
import com.cg.springmvcone.dto.Employee;
@Service
@Transactional
public class EmployeeServiceImpl implements IEmployeeService {

	@Autowired
	IEmployeeDAO employeeDAO;
	@Override
	public int addEmployeeData(Employee emp) {
		// TODO Auto-generatsed method stub
		return employeeDAO.addEmployeeData(emp) ;
	}

	@Override
	public List<Employee> showAllEmployee() {
		// TODO Auto-generated method stub
		return employeeDAO.showAllEmployee() ;
	}

	@Override
	public void deleteEmployee(int empId) {
		// TODO Auto-generated method stub
		employeeDAO.deleteEmployee(empId);
	}

	@Override
	public void updateEmployee(Employee emp) {
		// TODO Auto-generated method stub
		employeeDAO.updateEmployee(emp);
	}

	@Override
	public Employee searchEmployee(int empId) {
		// TODO Auto-generated method stub
		return employeeDAO.searchEmployee(empId);
	}

}
