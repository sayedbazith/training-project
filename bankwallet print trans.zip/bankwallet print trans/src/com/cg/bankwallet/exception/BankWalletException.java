package com.cg.bankwallet.exception;

public class BankWalletException extends Exception{

	public BankWalletException() {
		super();
	}

	public BankWalletException(String message) {
		super(message);
	}
}
