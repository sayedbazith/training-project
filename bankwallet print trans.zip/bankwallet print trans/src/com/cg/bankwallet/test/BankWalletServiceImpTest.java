package com.cg.bankwallet.test;


import static org.junit.Assert.*;

import org.junit.Test;

import com.cg.bankwallet.bean.BankWalletBean;
import com.cg.bankwallet.exception.BankWalletException;
import com.cg.bankwallet.service.BankWalletServiceImp;
import com.cg.bankwallet.service.IBankWalletService;

public class BankWalletServiceImpTest 
{
	IBankWalletService service=new BankWalletServiceImp();
	BankWalletBean bean=new BankWalletBean();
	
	@Test
	public void testAccountPositiveCase() throws BankWalletException
	{
		bean.setAccountnumber(2222);
		boolean result=service.validate(bean);
		assertTrue(result);
	}
	
	@Test
	public void testAccountNegative() throws BankWalletException
	{
		bean.setAccountnumber(900);
		boolean result=service.validate(bean);
		assertFalse(result);
	}
	
	@Test
	public void testAccountLimitCase() throws BankWalletException
	{
		bean.setAccountnumber(500000001);
		boolean result=service.validate(bean);
		assertFalse(result);
	}
}
