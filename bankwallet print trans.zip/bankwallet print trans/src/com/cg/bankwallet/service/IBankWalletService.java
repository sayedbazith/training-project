package com.cg.bankwallet.service;

import com.cg.bankwallet.bean.BankWalletBean;

public interface IBankWalletService {
	public BankWalletBean printTranscations(int accountNumber);
	public boolean validate(BankWalletBean bean);
}
