package com.cg.bankwallet.service;

import com.cg.bankwallet.bean.BankWalletBean;
import com.cg.bankwallet.dao.BankWalletDaoImp;
import com.cg.bankwallet.dao.IBankWalletDao;
import com.cg.bankwallet.exception.BankWalletException;

public class BankWalletServiceImp implements IBankWalletService {
	IBankWalletDao bankdao=new BankWalletDaoImp();
	boolean isvalid=false;
	@Override
	public BankWalletBean printTranscations(int accountNumber) {
		// TODO Auto-generated method stub
		return bankdao.printTranscations(accountNumber);
	}

	
	@Override
	public boolean validate(BankWalletBean bean) {
		// TODO Auto-generated method stub
	try
	{
		int account=bean.getAccountnumber();
		if((account>999) && (account<=50000))
			isvalid=true;
		
		else
			throw new BankWalletException("account number is not correct");
	}
	catch(BankWalletException ex){}
	return isvalid;
	}

}
