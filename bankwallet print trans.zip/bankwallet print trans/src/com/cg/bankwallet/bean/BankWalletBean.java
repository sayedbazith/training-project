package com.cg.bankwallet.bean;

public class BankWalletBean {
	private int accountnumber;

	
	
	
	public int getAccountnumber() {
		return accountnumber;
	}

	public void setAccountnumber(int accountnumber) {
		this.accountnumber = accountnumber;
	}
}
