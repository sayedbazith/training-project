package com.cg.bankwallet.dao;

import com.cg.bankwallet.bean.BankWalletBean;

public interface IBankWalletDao {
	public BankWalletBean printTranscations(int accountNumber);
}
