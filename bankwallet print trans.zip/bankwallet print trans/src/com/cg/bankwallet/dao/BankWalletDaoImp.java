package com.cg.bankwallet.dao;

import java.util.ArrayList;
import java.util.List;
import java.time.LocalDate;

import com.cg.bankwallet.bean.BankWalletBean;
import com.cg.bankwallet.exception.BankWalletException;

public class BankWalletDaoImp implements IBankWalletDao
{
	List<BankWalletBean> bankdetails=new ArrayList<BankWalletBean>();
	List<BankWalletBean> transcationdetails=new ArrayList<BankWalletBean>();
	BankWalletBean b;
	
	
	/*public void createAccount(BankWalletBean bean)
	{
		LocalDate today = LocalDate.now();
		String date=today.toString();
		bean.setDate(date);
		bankdetails.add(bean);
		
		
	}*/
	
	/*public BankWalletBean deposit(int accnum,int amount)
	{
		
		for (BankWalletBean bankWalletBean : bankdetails) 
		{
			if(bankWalletBean.getId())==accnum)
			{
				double d=	bankWalletBean.getBalance()+amount;
				bankWalletBean.setBalance(d);
				bankdetails.add(bankWalletBean);
				
				LocalDate today = LocalDate.now();
				String date=today.toString();
				bankWalletBean.setDate(date);
				transcationsdetails.add(bankWalletBean);
			}
			else
			{
				
				
				exception calling
			}
			
		}
		
	}*/
	
	
	/*public BankWalletBean withdrawl(int accnum,int amount)
	{
		
		for (BankWalletBean bankWalletBean : bankdetails) 
		{
			if(bankWalletBean.getId())==accnum)
			{
				double d=	bankWalletBean.getBalance()-amount;
				bankWalletBean.setBalance(d);
				bankdetails.add(bankWalletBean);
				
				LocalDate today = LocalDate.now();
				String date=today.toString();
				bankWalletBean.setDate(date);
				transcationsdetails.add(bankWalletBean);
			}
			else
			{
				
				
				exception calling
			}
			
		}
		
	}*/
	
	/*public BankWalletBean fundTransfer(int accnum,int amount)
	{
		
		for (BankWalletBean bankWalletBean : bankdetails) 
		{
			if(bankWalletBean.getId())==accnum)
			{
				double d=	bankWalletBean.getBalance()-amount;
				bankWalletBean.setBalance(d);
				bankdetails.add(bankWalletBean);
				
				LocalDate today = LocalDate.now();
				String date=today.toString();
				bankWalletBean.setDate(date);
				transcationsdetails.add(bankWalletBean);
			}
			else
			{
				
				
				exception calling
			}
		}
	}*/
	
	
	@Override
	public BankWalletBean printTranscations(int accountNumber) 
	{
		// TODO Auto-generated method stub
		try
		{
		
		for (BankWalletBean bankWalletBean : transcationdetails) 
		{
			if(bankWalletBean.getAccountnumber()==accountNumber)
			{
				System.out.println(bankWalletBean);
			}
			else
			{
				throw new BankWalletException();
			}
		}
		}
		catch(BankWalletException ex)
		{
			
		}
		
	
		
		return b;
	}



}
