package com.cg.crudpractice.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class PraEntity {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int praId;
	@Column
	private String praName;
	
	public int getPraId() {
		return praId;
	}
	public void setPraId(int praId) {
		this.praId = praId;
	}
	public String getPraName() {
		return praName;
	}
	public void setPraName(String praName) {
		this.praName = praName;
	}
	public PraEntity(int praId, String praName) {
		super();
		this.praId = praId;
		this.praName = praName;
	}
	public PraEntity() {
		super();
	}
	
	
}
