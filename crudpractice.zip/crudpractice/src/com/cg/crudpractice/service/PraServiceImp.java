package com.cg.crudpractice.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.crudpractice.dao.IPraDAO;
import com.cg.crudpractice.entity.PraEntity;

@Service
@Transactional
public class PraServiceImp implements IPraService {
	
	@Autowired
	IPraDAO dao;
	@Override
	public boolean add(PraEntity bean) {
		// TODO Auto-generated method stub
		return dao.add(bean);
	}

}
