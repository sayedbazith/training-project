package com.cg.crudpractice.service;

import com.cg.crudpractice.entity.PraEntity;

public interface IPraService {
	boolean add(PraEntity bean);
}
