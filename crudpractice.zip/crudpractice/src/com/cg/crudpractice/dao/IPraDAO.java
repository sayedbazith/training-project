package com.cg.crudpractice.dao;

import com.cg.crudpractice.entity.PraEntity;

public interface IPraDAO {
	boolean add(PraEntity bean);
}
