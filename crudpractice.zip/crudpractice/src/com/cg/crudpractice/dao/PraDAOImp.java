package com.cg.crudpractice.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import org.springframework.stereotype.Repository;

import com.cg.crudpractice.entity.PraEntity;
@Repository
public class PraDAOImp implements IPraDAO {
	
	@PersistenceContext
	EntityManager em;
	@Override
	public boolean add(PraEntity bean) {
		// TODO Auto-generated method stub
		boolean isValid=false;
		em.persist(bean);
		isValid=true;
		return isValid;
	}

}
