package com.cg.crudpractice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.crudpractice.entity.PraEntity;
import com.cg.crudpractice.service.IPraService;

@Controller
public class PraController {
	
	@Autowired
	IPraService service;
	
	@RequestMapping(value="home",method=RequestMethod.GET)
	public String showHome()
	{
		return "details";
	}
	
	@RequestMapping(value="addpra")
	public String addPra(@RequestParam("name") String name)
	{
		PraEntity bean=new PraEntity();
		bean.setPraName(name);
		boolean result=service.add(bean);
		if(result)
			return "success";
		else
			return "details";
	}
}
