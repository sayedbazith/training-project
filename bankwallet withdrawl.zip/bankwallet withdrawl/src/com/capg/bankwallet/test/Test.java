package com.capg.bankwallet.test;

import org.junit.Assert;
import org.junit.BeforeClass;
import com.capg.bankwallet.bean.BankWalletBean;
import com.capg.bankwallet.exception.BankWalletException;
import com.capg.bankwallet.service.BankWalletServiceImp;
import com.capg.bankwallet.service.IBankWalletService;

public class Test {

	private static IBankWalletService service = null;

	@BeforeClass
	public static void createInstance() {
		service = new BankWalletServiceImp();
	}
	
	
	
	@org.junit.Test
	public void testWithdrawedForWrongPhn() throws BankWalletException {
		BankWalletBean bean = new BankWalletBean();
		bean.setPhnNo("9059900988");
		bean.setWithdraw(2000);
		boolean result = service.withdraw(bean);
		Assert.assertFalse(result);
	}
	@org.junit.Test
	public void testWithdrawForNegative() throws BankWalletException {
		BankWalletBean bean = new BankWalletBean();
		bean.setPhnNo("9059900989");
		bean.setWithdraw(-2000);
		boolean result = service.withdraw(bean);
		Assert.assertFalse(result);
	}
	@org.junit.Test
	public void testWithdrawed() throws BankWalletException {
		BankWalletBean bean = new BankWalletBean();
		bean.setPhnNo("9059900989");
		bean.setWithdraw(2000);
		boolean result = service.withdraw(bean);
		Assert.assertTrue(result);
	}
	
	@org.junit.Test
	public void testForPhnlength() throws BankWalletException {
		BankWalletBean bean = new BankWalletBean();
		bean.setPhnNo("9059900");
		bean.setWithdraw(2000);
		boolean result = service.withdraw(bean);
		Assert.assertFalse(result);
	}
	@org.junit.Test
	public void testFornotnull() throws BankWalletException {
		BankWalletBean bean = new BankWalletBean();
		bean.setPhnNo(null);
		bean.setWithdraw(2000);
		boolean result = service.withdraw(bean);
		Assert.assertFalse(result);
	}
	@org.junit.Test
	public void testForonlynumbers() throws BankWalletException {
		BankWalletBean bean = new BankWalletBean();
		bean.setPhnNo("905ghd");
		bean.setWithdraw(2000);
		boolean result = service.withdraw(bean);
		Assert.assertFalse(result);
	
	}

}
