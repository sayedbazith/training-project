package com.capg.bankwallet.service;

import com.capg.bankwallet.bean.BankWalletBean;
import com.capg.bankwallet.dao.BankWalletDaoImp;
import com.capg.bankwallet.dao.IBankWalletDao;

public class BankWalletServiceImp implements IBankWalletService {
IBankWalletDao dao= new BankWalletDaoImp();
	@Override
	public boolean withdraw(BankWalletBean bean1) {
	
		return dao.withdraw(bean1);
	}

}
