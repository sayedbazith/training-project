package com.capg.bankwallet.service;

import com.capg.bankwallet.bean.BankWalletBean;

public interface IBankWalletService {
	public boolean withdraw(BankWalletBean bean1);
}
