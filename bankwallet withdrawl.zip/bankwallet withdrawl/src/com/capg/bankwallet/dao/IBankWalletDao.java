package com.capg.bankwallet.dao;

import com.capg.bankwallet.bean.BankWalletBean;



public interface IBankWalletDao {
	public boolean withdraw(BankWalletBean bean1);
}
