package com.capg.bankwallet.dao;

import java.time.LocalDate;
import java.util.ArrayList;

import com.capg.bankwallet.bean.BankWalletBean;
import com.capg.bankwallet.exception.BankWalletException;
import com.capg.bankwallet.exception.ExceptionMessages;
import com.capg.bankwallet.service.IBankWalletService;


public class BankWalletDaoImp implements IBankWalletDao {
	private static IBankWalletService service = null;
	ArrayList<BankWalletBean> list = new ArrayList<BankWalletBean>();

	public void addAccount() {
		BankWalletBean b1 = new BankWalletBean();
		b1.setPhnNo("9059900989");
		b1.setBalance(5000);
		list.add(b1);
		BankWalletBean b2 = new BankWalletBean();
		b2.setPhnNo("9059900979");
		b2.setBalance(5000);
		list.add(b2);

	}


	public boolean withdraw(BankWalletBean bean1) {
		addAccount();
		boolean status = false;
		try {
			BankWalletBean b1 = null;
			if(bean1.getWithdraw()<=0){
				throw new BankWalletException(ExceptionMessages.ERROR5);
			}
			for (BankWalletBean bean : list) {
				if (bean1.getPhnNo().equals(bean.getPhnNo())) {
					b1 = bean;
				}
			}
			if (bean1.getPhnNo() == null) {

				throw new BankWalletException(ExceptionMessages.ERROR1);
			}
			if (!(bean1.getPhnNo().matches("[7-9][0-9]{9}"))) {

				throw new BankWalletException(ExceptionMessages.ERROR2);
			}
				
				if (bean1.getWithdraw() >= b1.getBalance() - 500) {

				}
				else {
					b1.setBalance(b1.getBalance() - bean1.getWithdraw());
					status = true;
					System.out.println(b1.getBalance());

				}
				 LocalDate a = LocalDate.now();
				 System.out.println(a);
			
			
		} catch (Exception exception1) {
			System.out.println(exception1.getMessage());
		}

		return status;
	}



}
