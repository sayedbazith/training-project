package com.capg.bankwallet.exception;

public class ExceptionMessages extends BankWalletException {
	public static final String ERROR1 = "invalid phone no";
	public static final String ERROR2 = "phone number should contain only numbers";
	public static final String ERROR3 = "inadequate balance";
	public static final String ERROR4 = "4amount should be a positive value";
	public static final String ERROR5 = "5amount should be a positive value";


}
