package com.capg.bankwallet.exception;

public class BankWalletException extends Exception {

	

	public BankWalletException() {
		super();
		// TODO Auto-generated constructor stub
	}
	public BankWalletException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
}
